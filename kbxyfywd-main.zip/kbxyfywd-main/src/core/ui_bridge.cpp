/**
 * @file ui_bridge.cpp
 * @brief UI 桥接器实现
 * 
 * 统一管理所有 JavaScript 交互
 */

#include "ui_bridge.h"

// Windows 自定义消息
#include "window_messages.h"

// 外部声明：执行 JavaScript 的函数（在 demo.cpp 中定义）

// ============================================================================
// 单例实现
// ============================================================================

UIBridge& UIBridge::Instance() {
    static UIBridge instance;
    return instance;
}

// ============================================================================
// 初始化
// ============================================================================

void UIBridge::Initialize(HWND hWnd) {
    m_hwnd = hWnd;
}

// ============================================================================
// 常用 UI 更新方法
// ============================================================================

void UIBridge::UpdateHelperText(const std::wstring& text) {
    std::wstring script = L"if(window.updateHelperText) { window.updateHelperText('" + 
                          EscapeJsonString(text) + L"'); }";
    ExecuteJS(script);
}

void UIBridge::UpdatePacketCount(DWORD count) {
    std::wstring script = L"if(window.updatePacketCount) { window.updatePacketCount(" + 
                          std::to_wstring(count) + L"); }";
    ExecuteJS(script);
}

// ============================================================================
// 通用 JavaScript 执行方法
// ============================================================================

void UIBridge::ExecuteJS(const std::wstring& script) {
    if (script.empty() || !m_hwnd) return;

    const size_t len = script.length() + 1;
    wchar_t* pScript = new (std::nothrow) wchar_t[len];
    if (!pScript) return;

    wmemcpy_s(pScript, len, script.c_str(), len);

    if (!PostMessage(m_hwnd, AppMessage::kExecuteJs, 0, (LPARAM)pScript)) {
        delete[] pScript;
    }
}

// ============================================================================
// 封包列表批量投递
// ============================================================================

void UIBridge::QueuePacketEntry(PacketUiEntry entry) {
    if (!m_hwnd) return;

    // 在调用线程里先把本条拼成 JS 数组项：hex 可能有几 KB，
    // 拼装成本属于产生封包的线程，不该挪到 UI 线程逐条做。
    std::wstring item;
    item.reserve(entry.hex.size() + entry.label.size() + 48);
    item += L'[';
    item += std::to_wstring(entry.index);
    item += (entry.bSend ? L",1," : L",0,");
    item += L"'";
    item += EscapeJsonString(entry.hex);
    item += L"','";
    item += EscapeJsonString(entry.time);
    item += L"','";
    item += EscapeJsonString(entry.label);
    item += L"'],";

    bool needPost = false;
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_pendingEntries += item;
        m_pendingLastIndex = entry.index;
        if (!m_flushPosted) {
            m_flushPosted = true;
            needPost = true;
        }
    }

    // 只有「队列从空变为非空」时投递一次。UI 线程处理消息的间隙里
    // socket 线程塞进来的封包会被自动合并进同一批。
    if (needPost && !PostMessage(m_hwnd, AppMessage::kFlushPacketEntries, 0, 0)) {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_flushPosted = false;
    }
}

void UIBridge::FlushPacketEntries() {
    std::wstring items;
    std::size_t total = 0;
    unsigned int generation = 0;
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_flushPosted = false;
        items.swap(m_pendingEntries);
        total = m_pendingLastIndex;
        generation = m_packetGeneration;
    }

    if (items.empty()) return;
    if (items.back() == L',') items.pop_back();

    std::wstring script;
    script.reserve(items.size() + 96);
    script += L"if(window.addPacketsToList){window.addPacketsToList([";
    script += items;
    script += L"],";
    script += std::to_wstring(total);
    script += L",";
    script += std::to_wstring(generation);
    script += L");}";

    // 走 ExecuteJS 而不是直接 ExecuteScriptInWebView2：本函数虽然只从
    // 主窗口过程调用，但仍让脚本经由 UI 线程消息统一下发，避免将来误用
    // 时在非 UI 线程直接摸 WebView2。
    ExecuteJS(script);
}

void UIBridge::ClearPendingPacketEntries() {
    std::lock_guard<std::mutex> lock(m_queueMutex);
    m_pendingEntries.clear();
    m_pendingLastIndex = 0;
    // 世代号 +1：已经投递出去、但还没被 UI 线程执行的那批脚本带的是旧世代号，
    // JS 侧据此丢弃，避免重建后的新列表被旧行追加。
    ++m_packetGeneration;
}

unsigned int UIBridge::PacketListGeneration() {
    std::lock_guard<std::mutex> lock(m_queueMutex);
    return m_packetGeneration;
}

// ============================================================================
// 辅助方法
// ============================================================================

// 注意：这里做的是"JS 字符串字面量转义"（含单引号），不是严格 JSON 转义。
// 全部调用点都是把结果拼进 JS 字面量；若将来要生成真 JSON 再 JSON.parse，
// 单引号的 ' 不合法，需另走一条转义路径。
std::wstring UIBridge::EscapeJsonString(const std::wstring& input) {
    std::wstring result;
    result.reserve(input.length() * 2); // 预留更多空间，因为转义字符会增加长度
    
    for (wchar_t c : input) {
        switch (c) {
            case L'"':  result += L"\\\""; break;
            case L'\'': result += L"\\'"; break;
            case L'\\': result += L"\\\\"; break;
            case L'\n': result += L"\\n"; break;
            case L'\r': result += L"\\r"; break;
            case L'\t': result += L"\\t"; break;
            case L'\b': result += L"\\b"; break;
            case L'\f': result += L"\\f"; break;
            default:    
                // 对于控制字符（小于0x20），使用\uXXXX格式
                if (c < 0x20) {
                    wchar_t buf[8];
                    swprintf_s(buf, L"\\u%04x", static_cast<unsigned int>(c));
                    result += buf;
                } else {
                    result += c; 
                }
                break;
        }
    }
    return result;
}
