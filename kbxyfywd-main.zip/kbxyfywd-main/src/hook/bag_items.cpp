#include <windows.h>

#include <cstdint>
#include <cstdio>
#include <mutex>
#include <string>
#include <vector>

#include "activity_states_internal.h"
#include "battle_six.h"
#include "byte_reader.h"
#include "hook_shared.h"
#include "packet_builder.h"
#include "ui_bridge.h"
#include "wpe_hook_internal.h"

// 背包映射由收包线程在 ProcessPackageDataResponse 里整体重建，
// 活动线程会在发包前查 position，两边必须用同一把锁。
namespace {
std::mutex g_packItemsMutex;
}

// ============ 灵玉相关功能实现 ============

// 解析 JSON 数组字符串，如 ["37","52"] 或 ['37','52']，返回 "37_52" 格式
static std::string ParseIndicesArray(const std::wstring& jsonArray) {
    std::string result;

    // 直接转换为 ANSI 字符串
    int len = WideCharToMultiByte(CP_ACP, 0, jsonArray.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (len <= 0) {
        return result;
    }

    std::string jsonA(len, 0);
    WideCharToMultiByte(CP_ACP, 0, jsonArray.c_str(), -1, &jsonA[0], len, nullptr, nullptr);

    // 移除空白，并将单引号替换为双引号
    std::string clean;
    for (char c : jsonA) {
        if (!isspace((unsigned char)c)) {
            if (c == '\'') clean += '"';  // 单引号转双引号
            else clean += c;
        }
    }

    // 查找 [ 和 ]
    size_t start = clean.find('[');
    size_t end = clean.find(']');
    if (start == std::string::npos || end == std::string::npos || end <= start) {
        return result;
    }

    std::string content = clean.substr(start + 1, end - start - 1);

    // 用逗号分割
    size_t pos = 0;
    bool first = true;
    while (pos < content.length()) {
        size_t nextComma = content.find(',', pos);
        std::string item;
        if (nextComma == std::string::npos) {
            item = content.substr(pos);
            pos = content.length();
        } else {
            item = content.substr(pos, nextComma - pos);
            pos = nextComma + 1;
        }

        // 移除引号
        size_t q1 = item.find('"');
        size_t q2 = item.find_last_of('"');
        if (q1 != std::string::npos && q2 != std::string::npos && q2 > q1) {
            item = item.substr(q1 + 1, q2 - q1 - 1);
        }

        if (!item.empty()) {
            if (!first) result += "_";
            result += item;
            first = false;
        }
    }

    return result;
}

// 发送查询灵玉封包（2个封包）
BOOL SendQueryLingyuPacket() {
    // 查询灵玉背包列表（背包中的灵玉）
    // sendMessage(MsgDoc.OP_CLIENT_SPIRIT_EQUIP_ALL.send, userId, [1])
    // Body: int32 数组长度(1) + int32 元素值
    
    // 检查是否有卡布号
    if (g_userId == 0) {
        return FALSE;
    }

    const uint32_t userId = g_userId.load();

    // 封包1 查背包中的灵玉（body 元素值 = 1），封包2 查已装备的灵玉（= 2），
    // 两者只差 body 那个元素，用同一个构造式生成。
    // body 布局：int32 数组长度(固定 1) + int32 元素值。
    const auto buildQuery = [userId](int32_t slot) {
        return PacketBuilder()
            .SetOpcode(Opcode::SPIRIT_EQUIP_ALL_SEND)
            .SetParams(userId)
            .WriteInt32(1)
            .WriteInt32(slot)
            .Build();
    };

    const auto packet1 = buildQuery(1);
    BOOL result1 = SendPacketBytes(packet1);

    // 延迟300ms发送第二个封包
    ManagedThread::SleepCancellable(300);

    const auto packet2 = buildQuery(2);
    BOOL result2 = SendPacketBytes(packet2);

    return result1 && result2;
}

// 发送查询背包封包（2个包）
BOOL SendQueryBagPacket() {
    // 封包1: 44 53 00 00 18 18 12 00 00 00 00 00（空 body，params=0）
    const auto packet1 = PacketBuilder()
        .SetOpcode(0x00121818)
        .SetParams(0)
        .Build();

    // 封包2: 44 53 00 00 11 10 12 00 FF FF FF FF（空 body，params=0xFFFFFFFF）
    const auto packet2 = PacketBuilder()
        .SetOpcode(0x00121011)
        .SetParams(0xFFFFFFFF)
        .Build();

    BOOL result1 = SendPacketBytes(packet1);

    // 延迟50ms发送第二个封包
    ManagedThread::SleepCancellable(50);

    BOOL result2 = SendPacketBytes(packet2);

    return result1 && result2;
}

// 发送一键分解封包 - 异步版本
// jsonArray: JSON数组字符串，如 ["37","52"]
struct DecomposeTaskData {
    std::string indices;
};

// 分解任务完成消息

DWORD WINAPI DecomposeThreadProc(LPVOID lpParam) {
    DecomposeTaskData* taskData = static_cast<DecomposeTaskData*>(lpParam);

    // 立即启用阻止发送功能，阻止 1185792 和 1185809 的发送。
    // 用 RAII 收尾：分解过程中任何提前 return 或异常都要把全局标志放掉，
    // 否则整个进程后续所有发包都会被静默拦掉。
    struct BlockOpcodeSendGuard {
        BlockOpcodeSendGuard() { g_blockOpcodeSend = true; }
        ~BlockOpcodeSendGuard() { g_blockOpcodeSend = false; }
    } blockOpcodeSendGuard;

    // 解析索引数组（例如 "62_61" -> ["62", "61"]）
    std::vector<std::string> indexList;
    std::string current;
    for (size_t i = 0; i < taskData->indices.length(); i++) {
        if (taskData->indices[i] == '_') {
            if (!current.empty()) {
                indexList.push_back(current);
                current.clear();
            }
        } else {
            current += taskData->indices[i];
        }
    }
    if (!current.empty()) {
        indexList.push_back(current);
    }

    // 构建分解封包: 44 53 00 00 16 18 12 00 + 索引(4字节LE)
    // 例如: 分解索引 1234 (0x04D2) -> 44 53 00 00 16 18 12 00 D2 04 00 00

    BOOL allSuccess = TRUE;

    // 逐个分解每个灵玉
    for (size_t i = 0; i < indexList.size(); i++) {
        if (ManagedThread::StopRequested()) {
            allSuccess = FALSE;
            break;
        }
        const auto& indexStr = indexList[i];

        // 将字符串索引转换为整数
        int indexValue = 0;
        if (!TryParseInt32Decimal(indexStr, indexValue)) {
            allSuccess = FALSE;
            continue;
        }

        // 使用 PacketBuilder 构建分解封包
        // Opcode: RESOLVE_SPIRIT_SEND, Params: symmIndex
        auto packet = PacketBuilder()
            .SetOpcode(Opcode::RESOLVE_SPIRIT_SEND)
            .SetParams(static_cast<uint32_t>(indexValue))
            .Build();

        // 发送分解封包
        BOOL result = SendPacketBytes(packet);

        // 生成十六进制封包字符串并发送到UI
        std::string hexPacket = HexToString(packet.data(), static_cast<DWORD>(packet.size())) + " ";

        // 向UI线程发送十六进制封包信息
        if (g_hWnd) {
            HexPacketData* hexData = new HexPacketData();
            hexData->len = hexPacket.length() + 1;
            hexData->data = new char[hexData->len];
            strcpy_s(hexData->data, hexData->len, hexPacket.c_str());

            PostMessage(g_hWnd, AppMessage::kDecomposeHexPacket, (WPARAM)hexData, 0);
        }

        // 延迟200ms再分解下一个，避免过快发送
        if (i + 1 < indexList.size()) {
            ManagedThread::SleepCancellable(200);
        }

        // 更新整体成功状态
        allSuccess = allSuccess && result;
    }

    // 发送完成消息到UI线程
    if (g_hWnd) {
        PostMessage(g_hWnd, AppMessage::kDecomposeComplete, (WPARAM)allSuccess, 0);
    }
    
    // 清理内存
    delete taskData;
    
    return allSuccess;
}

BOOL SendDecomposeLingyuPacket(const std::wstring& jsonArray) {
    if (jsonArray.empty()) {
        return FALSE;
    }

    // 解析 JSON 数组，构造 indices 字符串
    std::string indices = ParseIndicesArray(jsonArray);
    if (indices.empty()) {
        return FALSE;
    }

    // 创建任务数据结构
    DecomposeTaskData* taskData = new DecomposeTaskData();
    taskData->indices = indices;

    // 创建新线程处理分解任务，避免阻塞主线程
    HANDLE hThread = CreateManagedThread(NULL, 0, DecomposeThreadProc, taskData, 0, NULL, L"decompose");
    if (hThread) {
        CloseHandle(hThread);
        return TRUE;
    } else {
        delete taskData;
        return FALSE;
    }
}

// 发送查询妖怪背包封包
// Opcode: 1187329, Params: 0
BOOL SendQueryMonsterPacket() {
    auto packet = PacketBuilder()
        .SetOpcode(1187329)
        .SetParams(0)
        .Build();
    return SendPacketBytes(packet);
}

BOOL SendReqPackageDataPacket(uint32_t packType) {
    // 封包格式: Opcode=1183761, Params=packType, Body=空
    std::vector<uint8_t> packet = PacketBuilder()
        .SetOpcode(Opcode::REQ_PACKAGE_DATA_SEND)
        .SetParams(packType)
        .Build();
    
    return SendPacketBytes(packet);
}

/**
 * @brief 处理背包数据响应
 * @param packet 封包数据
 */
void ProcessPackageDataResponse(const GamePacket& packet) {
    if (packet.body.size() < 8) {
        UIBridge::Instance().UpdateHelperText(L"背包数据响应格式错误");
        return;
    }
    
    size_t offset = 0;
    ByteReader reader(packet.body, offset);
    size_t bodySize = packet.body.size();
    
    // 读取 isocode（占位字段，仅需推进 offset）
    (void)reader.I32();
    
    // 读取 packcount（包数量）
    int packcount = reader.I32();
    
    // 重建整张映射表：先持锁清空再填充，JS 调用留到锁外。
    std::wstring itemCountsJson = L"{";
    size_t itemTotal = 0;
    {
        std::lock_guard<std::mutex> packLock(g_packItemsMutex);
        g_itemPositionMap.clear();
        g_packItems.clear();
    
    // 遍历每个包
    for (int i = 0; i < packcount; i++) {
        // 检查是否有足够的空间读取 packcode, packid, count (共12字节)
        if (offset + 12 > bodySize) break;
        
        int packcode = reader.I32();
        (void)reader.I32();  // packid：占位字段，仅需推进 offset
        int count = reader.I32();
        
        // 遍历包内物品
        for (int j = 0; j < count; j++) {
            // 检查是否有足够的空间读取 position 和 id (共8字节)
            if (offset + 8 > bodySize) break;
            
            PackItemInfo item;
            item.packcode = packcode;
            item.position = reader.I32();
            item.id = reader.I32();
            
            if (item.id > 0) {
                // 检查是否有足够的空间读取 count (4字节)
                if (offset + 4 > bodySize) break;
                
                item.count = reader.I32();
                
                // 保存到列表
                g_packItems.push_back(item);
                
                // 建立ID -> position映射
                g_itemPositionMap[item.id] = item.position;
            }
        }
    }
    
        // 构建道具数量JSON
        bool first = true;
        for (const auto& item : g_packItems) {
            if (!first) itemCountsJson += L",";
            first = false;
            itemCountsJson += L"\"" + std::to_wstring(item.id) + L"\":" + std::to_wstring(item.count);
        }
        itemCountsJson += L"}";
        itemTotal = g_packItems.size();
    }
    
    std::wstring script = L"if(window.updateItemCounts) { window.updateItemCounts(" + itemCountsJson + L"); }";
    UIBridge::Instance().ExecuteJS(script);
    
    // 更新UI
    wchar_t msg[128];
    swprintf_s(msg, L"背包数据已更新，共 %zu 个物品", itemTotal);
    UIBridge::Instance().UpdateHelperText(msg);
}

/**
 * @brief 购买道具
 * @param itemId 道具ID
 * @param count 购买数量
 * @return 发送是否成功
 * @note 封包格式: Opcode=1183760, Params=itemId, Body=[count]
 */
BOOL SendBuyGoodsPacket(uint32_t itemId, uint32_t count) {
    // 封包格式: Opcode=1183760, Params=itemId, Body=[count]
    std::vector<uint8_t> packet = PacketBuilder()
        .SetOpcode(Opcode::BUY_GOODS_SEND)
        .SetParams(itemId)
        .WriteUInt32(count)
        .Build();
    
    return SendPacketBytes(packet);
}

/**
 * @brief 使用道具（战斗中）
 * @param itemId 道具ID
 * @param position 物品位置索引（如果为0则从映射表查找）
 * @return 发送是否成功
 * @note 封包格式: Opcode=1186050, Params=2, Body=[packcode=1, position, sid=1]
 */
BOOL SendUseItemInBattlePacket(uint32_t itemId, uint32_t position) {
    // 如果未指定位置，从映射表中查找
    if (position == 0) {
        std::lock_guard<std::mutex> packLock(g_packItemsMutex);
        auto it = g_itemPositionMap.find(itemId);
        if (it == g_itemPositionMap.end()) {
            return FALSE;
        }
        position = it->second;
    }
    
    // 封包格式: Opcode=1186050, Params=2, Body=[packcode, position, sid]
    // packcode = 1 (道具背包), sid = 1 (玩家角色)
    std::vector<uint8_t> packet = PacketBuilder()
        .SetOpcode(Opcode::USER_OP_SEND)
        .SetParams(2)
        .WriteUInt32(1)        // packcode = 1
        .WriteUInt32(position) // position
        .WriteUInt32(1)        // sid = 1
        .Build();
    
    return SendPacketBytes(packet);
}

// ============================================================================
// 封包回调
// ============================================================================

