#include "byte_reader.h"
#include "packet_parser.h"

#include "bounded_reader.h"
#include <MemoryModule.h>
#include "zlib.h"
#include "battle_roster.h"
#include "battle_activity_hooks.h"
#include "app_host.h"
#include "packet_io.h"
#include "ui_bridge.h"
#include "utils.h"
#include <wininet.h>
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <functional>
#include <limits>
#include <mutex>
#include <unordered_map>

// 轻量级ZIP解压辅助函数（纯内存，使用已加载的zlib）
#include "embedded/minizip_helper.h"

// minizip module and functions
// 拼包缓冲上限：对端持续发数据却拼不出完整包时清空重来，避免无限增长。
static constexpr size_t kMaxReceiveBufferBytes = 8u * 1024u * 1024u;

std::vector<uint8_t> PacketParser::g_recvBuffer;
std::mutex g_parserLifecycleMutex;


// 战斗包解析的串行化锁。
// 每个战斗分支都是"取快照 → 改 → 写回"（BattleSession::Replace），中间会调用
// BattleActivity::SyncAutoBattle 等外部代码。如果两条线程同时处理两个战斗包，
// 后写回的那条会把另一条刚算出的血量/状态覆盖掉 —— 表现就是"偶尔掉血不生效"。
// 用 recursive_mutex：ProcessBattlePacketSafe 内部会调用 ClearBattleState。
static std::recursive_mutex g_battleParseMutex;

// 全局数据映射表的互斥锁
static std::mutex g_dataMapsMutex;
std::unordered_map<int, std::wstring> g_petNames;
std::unordered_map<int, std::wstring> g_skillNames;
std::unordered_map<int, int> g_skillPowers;  // 技能ID -> 威力值
std::unordered_map<int, int> g_skillRanges;  // 技能ID -> range，2 表示作用于己方

static std::unordered_map<int, std::wstring> g_toolNames;
static std::unordered_map<int, std::wstring> g_mapNames;
std::unordered_map<int, std::wstring> g_elemNames;             // 系别名称映射
std::unordered_map<int, std::wstring> g_geniusNames;           // 性格名称映射
static std::unordered_map<int, std::wstring> g_aptitudeNames;  // 资质名称映射
std::unordered_map<int, int> g_petElems;                       // 妖怪ID -> 系别ID映射
static std::unordered_map<int, std::wstring> g_bufNames;       // Buff 名称映射 (从 bufInfo.xml)
static std::unordered_map<int, std::wstring> g_bufDescs;       // Buff 描述映射



// BOSS列表结构体和全局变量
struct BossInfo {
    int id;
    std::wstring name;
    int elem;
};
// g_bossList 由 g_dataMapsMutex 保护：写入在 ParseBossXml（分发/数据加载线程），
// 读取在 SendBossListToUI（WebView2 加载完成回调所在线程），两边线程不同。
static std::vector<BossInfo> g_bossList;

// ============================================================================
// Buff 名称常量 (参考 AS3 BufData.as BUF_NAME)
// ============================================================================
struct BufNameEntry {
    int id;
    const wchar_t* name;
};

static const BufNameEntry BUF_NAME_ENTRIES[] = {
    {1, L"昏迷"}, {2, L"流血"}, {3, L"速度下降"}, {4, L"速度提升"},
    {5, L"防御力下降"}, {6, L"防御力提升"}, {7, L"攻击力下降"}, {8, L"攻击力提升"},
    {9, L"中毒"}, {10, L"受到法术伤害异常"}, {11, L"受到物理伤害异常"},
    {12, L"不能使用物理技能"}, {14, L"不能使用法术技能"},
    {18, L"法术下降"}, {19, L"法术提升"}, {20, L"命中率提升"}, {21, L"命中率下降"},
    {22, L"抗性提升"}, {23, L"抗性下降"}, {26, L"睡眠"}, {27, L"迷惑"},
    {28, L"疲劳"}, {29, L"灼伤"}, {30, L"激怒"}, {31, L"麻痹"},
    {32, L"混乱"}, {33, L"吸血"}, {34, L"窒息"}, {36, L"加血"},
    {37, L"加血"}, {47, L"冰冻"}, {48, L"自身血量低于50%时伤害加倍"},
    {49, L"所有增益状态被消除"}, {50, L"所有负面状态被去除"},
    {62, L"加血"}, {63, L"所有负面状态被去除"}
};

// 特殊 Buff ID 数组 (需要根据 param1 正负判断增益/减益)
static const int SPECIAL_BUF_IDS[] = {3, 4, 5, 6, 7, 8, 18, 19, 21, 20, 23, 22};

// ============================================================================
// XML解析辅助函数
// ============================================================================

static void TrimTrailingWhitespace(std::wstring& text) {
    while (!text.empty() && (text.back() == L' ' || text.back() == L'\t' ||
           text.back() == L'\n' || text.back() == L'\r')) {
        text.pop_back();
    }
}

static bool TryParseInt(const std::string& text, int& value) {
    if (text.empty()) {
        return false;
    }

    char* end = nullptr;
    const long parsed = std::strtol(text.c_str(), &end, 10);
    if (end == text.c_str() || *end != '\0') {
        return false;
    }

    value = static_cast<int>(parsed);
    return true;
}

static bool ExtractTagValue(const std::string& xml, const char* tagName, std::string& value, size_t startPos = 0) {
    const std::string openTag = std::string("<") + tagName + ">";
    const std::string closeTag = std::string("</") + tagName + ">";

    size_t openPos = xml.find(openTag, startPos);
    if (openPos == std::string::npos) {
        return false;
    }
    openPos += openTag.size();

    size_t closePos = xml.find(closeTag, openPos);
    if (closePos == std::string::npos) {
        return false;
    }

    value = xml.substr(openPos, closePos - openPos);
    return true;
}

static const wchar_t* FindBuiltInBufName(int bufId) {
    for (const auto& entry : BUF_NAME_ENTRIES) {
        if (entry.id == bufId) {
            return entry.name;
        }
    }
    return nullptr;
}

static bool IsSpecialBufId(int bufId) {
    for (int id : SPECIAL_BUF_IDS) {
        if (id == bufId) {
            return true;
        }
    }
    return false;
}

static bool ExtractAttributeValue(const std::string& tagText, const char* attrName, std::string& value) {
    const std::string pattern = std::string(attrName) + "=";
    size_t pos = tagText.find(pattern);
    if (pos == std::string::npos) {
        return false;
    }

    pos += pattern.size();
    while (pos < tagText.size() && (tagText[pos] == ' ' || tagText[pos] == '\t')) {
        ++pos;
    }
    if (pos >= tagText.size()) {
        return false;
    }

    char quote = 0;
    if (tagText[pos] == '\'' || tagText[pos] == '"') {
        quote = tagText[pos++];
    }

    const size_t end = quote ? tagText.find(quote, pos)
                             : tagText.find_first_of(" \t\r\n>", pos);
    if (end == std::string::npos) {
        return false;
    }

    value = tagText.substr(pos, end - pos);
    return true;
}

static bool FindElementBlock(const std::string& xml,
                             const char* tagName,
                             size_t searchStart,
                             size_t& contentStart,
                             size_t& closeStart,
                             size_t& nextPos,
                             std::string* startTagText = nullptr) {
    const std::string openPattern = std::string("<") + tagName;
    const std::string closePattern = std::string("</") + tagName + ">";

    size_t openPos = xml.find(openPattern, searchStart);
    if (openPos == std::string::npos) {
        return false;
    }

    const size_t tagEnd = xml.find('>', openPos);
    if (tagEnd == std::string::npos) {
        return false;
    }

    if (startTagText) {
        *startTagText = xml.substr(openPos, tagEnd - openPos + 1);
    }

    contentStart = tagEnd + 1;
    closeStart = xml.find(closePattern, contentStart);
    if (closeStart == std::string::npos) {
        return false;
    }

    nextPos = closeStart + closePattern.size();
    return true;
}

static bool FindSectionByType(const std::string& xml, const char* typeValue, std::string& section) {
    size_t searchPos = 0;
    std::string startTag;
    size_t contentStart = 0;
    size_t closeStart = 0;
    size_t nextPos = 0;

    while (FindElementBlock(xml, "items", searchPos, contentStart, closeStart, nextPos, &startTag)) {
        std::string actualType;
        if (ExtractAttributeValue(startTag, "type", actualType) && actualType == typeValue) {
            section = xml.substr(contentStart, closeStart - contentStart);
            return true;
        }
        searchPos = nextPos;
    }

    return false;
}

static void ParseNamedItemsSection(const std::string& section, std::unordered_map<int, std::wstring>& target, int startIndex) {
    size_t searchPos = 0;
    int index = startIndex;

    while (true) {
        size_t tagPos = section.find("<item", searchPos);
        if (tagPos == std::string::npos) {
            break;
        }

        const size_t tagEnd = section.find('>', tagPos);
        if (tagEnd == std::string::npos) {
            break;
        }

        std::string tagText = section.substr(tagPos, tagEnd - tagPos + 1);
        std::string name;
        if (ExtractAttributeValue(tagText, "name", name)) {
            target[index++] = Utf8ToWide(name);
        }

        searchPos = tagEnd + 1;
    }
}

// ============================================================================
// 妖怪背包数据全局变量（用于副本跳层等功能）
// ============================================================================
namespace {
// 保护 g_monsterData：收包线程重建、活动线程读快照。
std::mutex g_monsterDataMutex;
}  // namespace

MonsterData g_monsterData;

MonsterData SnapshotMonsterData() {
    std::lock_guard<std::mutex> lock(g_monsterDataMutex);
    return g_monsterData;
}

/**
 * @brief 解析属性强化/弱化等级
 * @details 游戏里攻击/防御/速度/法术/抗性/命中的增减状态都是 1~6 级，
 *          AS3 的 BufData.tipString 也是直接拿 param1 当等级用（param1 + "级"）。
 *          所以正常封包里 param1 就在 1~6；一旦出现 1000000 这类定点/百分比编码
 *          或字段错位，旧代码会拼出"速度提升1000000级"这种天文数字。
 *          这里统一收敛到 1~6：
 *          1) param1 在 1~6 直接用；
 *          2) 否则退回 param2（部分封包把等级放在 param2）；
 *          3) 再否则按 1000000/100/10 这类定点缩小后再判断；
 *          4) 仍无法判定时按满级 6 处理，保证不会显示异常数字。
 */
static int ResolveBufLevel(int param1, int param2) {
    auto normalize = [](long long raw) -> int {
        if (raw < 0) raw = -raw;
        if (raw >= 1 && raw <= 6) return static_cast<int>(raw);
        static const long long kScales[] = {1000000LL, 100000LL, 10000LL, 1000LL, 100LL, 10LL};
        for (long long scale : kScales) {
            if (raw % scale != 0) continue;
            const long long scaled = raw / scale;
            if (scaled >= 1 && scaled <= 6) return static_cast<int>(scaled);
        }
        return 0;
    };
    // 实测封包：param1 = 10000006（10*1e6 + 6 这类定点值），param2 = 2，
    // 游戏内显示的是 2 级 —— 等级取的是 param2；param1 只是该状态的数值。
    int level = normalize(param2);
    if (level == 0) level = normalize(param1);
    if (level == 0 && param1 >= 1000000) {
        // param1 形如 <定点值>*10 + 等级，低位数字就是等级（兜底）。
        const int low = param1 % 10;
        if (low >= 1 && low <= 6) level = low;
    }
    return level;
}

/**
 * @brief 获取 Buff 名称
 * @param bufId Buff ID
 * @param param1 参数1 (用于特殊 Buff 的等级判断)
 * @return Buff 名称
 */
static int ResolveBufLevel(int param1, int param2);

static std::wstring GetBufName(int bufId, int param1 = 0, int param2 = 0) {
    // 先从 bufInfo.xml 加载的数据中查找
    {
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        auto it = g_bufNames.find(bufId);
        if (it != g_bufNames.end()) {
            return it->second;
        }
    }
    
    // 使用内置的名称映射
    const wchar_t* builtInName = FindBuiltInBufName(bufId);
    if (builtInName != nullptr) {
        std::wstring baseName = builtInName;

        if (IsSpecialBufId(bufId)) {
            const int level = ResolveBufLevel(param1, param2);
            if (level >= 1) {
                return baseName + std::to_wstring(level) + L"级";
            }
        }
        return baseName;
    }
    
    return L"未知状态";
}

/**
 * @brief 获取 Buff 提示文本
 * @param bufId Buff ID
 * @param param1 参数1
 * @param param2 参数2
 * @return 提示文本
 */
static std::wstring GetBufTipString(int bufId, int param1, int param2) {
    // 先从 bufInfo.xml 加载的数据中查找
    std::wstring desc;
    {
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        auto it = g_bufDescs.find(bufId);
        if (it != g_bufDescs.end()) {
            desc = it->second;
        }
    }
    
    if (!desc.empty()) {
        // 替换占位符
        size_t pos;
        if ((pos = desc.find(L"#num1#")) != std::wstring::npos) {
            desc.replace(pos, 6, std::to_wstring(param1));
        }
        if ((pos = desc.find(L"#num2#")) != std::wstring::npos) {
            desc.replace(pos, 6, std::to_wstring(param2));
        }
        return desc;
    }
    
    // 返回基本名称（带上解析出的等级，保证与名称一致）
    return GetBufName(bufId, param1, param2);
}


static void ApplyBattleBufToPet(BattleEntity& pet, const BufData& sourceBuf) {
    BufData buf = sourceBuf;
    buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
    buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);

    // Standalone type 4/5 are blood/recover events, not persistent Buff rows.
    // Types 3/6 are PP append events and are likewise kept in the round record.
    if (buf.addOrRemove == BufDataType::BUF_TYPE_3 ||
        buf.addOrRemove == BufDataType::BUF_TYPE_4 ||
        buf.addOrRemove == BufDataType::BUF_TYPE_5 ||
        buf.addOrRemove == BufDataType::BUF_TYPE_6) {
        return;
    }

    if (buf.addOrRemove == BufDataType::BUF_TYPE_0) {
        for (auto it = pet.bufArr.begin(); it != pet.bufArr.end(); ) {
            if (it->bufId == buf.bufId) {
                it = pet.bufArr.erase(it);
            } else {
                ++it;
            }
        }
        return;
    }

    bool replaced = false;
    for (auto& existing : pet.bufArr) {
        if (existing.bufId == buf.bufId) {
            // BATTLE_BUFS 这类同步包不带剩余回合数（round 恒为 0）。若直接整条替换，
            // 面板上本来显示“剩余 3 回合”的状态会被打回 0 并被 UI 隐藏回合数。
            // 只有在新的 round > 0 时才更新，否则沿用已有的。
            if (buf.round == 0) buf.round = existing.round;
            existing = buf;
            replaced = true;
            break;
        }
    }
    if (!replaced) {
        pet.bufArr.push_back(buf);
    }

    // HP changes are authoritative only when the protocol carries the resulting HP
    // fields (for example BATTLE_ROUND). Do not derive HP from a Buff id/parameter.
}

static void RemoveBattleBufFromPet(BattleEntity& pet, int32_t bufId) {
    for (auto it = pet.bufArr.begin(); it != pet.bufArr.end(); ) {
        if (it->bufId == bufId) {
            it = pet.bufArr.erase(it);
        } else {
            ++it;
        }
    }
}

static bool BattlePetHasBuf(const BattleEntity& pet, int32_t bufId) {
    for (const auto& buf : pet.bufArr) {
        if (buf.bufId == bufId) return true;
    }
    return false;
}

/// 按 uniqueId 在双方名册里找实体（跳过占位槽）。用于“换宠提示/日志”等只读场景。
static const BattleEntity* FindBattleEntityByUniqueId(const BattleData& battle, int32_t uniqueId) {
    if (uniqueId == 0) return nullptr;
    for (const auto& pet : battle.myPets) {
        if (!pet.placeholder && pet.uniqueId == uniqueId) return &pet;
    }
    for (const auto& pet : battle.otherPets) {
        if (!pet.placeholder && pet.uniqueId == uniqueId) return &pet;
    }
    return nullptr;
}


static BattleEntity* FindBattleEntityBySid(BattleData& battle, int32_t sid) {
    // sid == 0 是"没填"：未揭示的占位妖怪 sid 也是 0，按 0 去找会一路挂到
    // 列表里第一只占位身上（表现就是状态/掉血显示在第一只妖怪上）。
    if (sid == 0) return nullptr;
    // 先取在场那只：换宠可能让同一个 sid 在名册里出现两次（旧槽位留在原地
    // 未清掉），直接返回第一个会命中已经下场的那份，提示与面板就对不上。
    for (auto& pet : battle.myPets) {
        if (pet.sid == sid && pet.state == 1) return &pet;
    }
    for (auto& pet : battle.otherPets) {
        if (pet.sid == sid && pet.state == 1) return &pet;
    }
    for (auto& pet : battle.myPets) {
        if (pet.sid == sid) return &pet;
    }
    for (auto& pet : battle.otherPets) {
        if (pet.sid == sid) return &pet;
    }
    return nullptr;
}

static const BattleEntity* FindBattleEntityBySid(const BattleData& battle, int32_t sid) {
    if (sid == 0) return nullptr;  // 0 = 未填，别匹配到 sid 也为 0 的占位妖怪
    for (const auto& pet : battle.myPets) {
        if (pet.sid == sid && pet.state == 1) return &pet;
    }
    for (const auto& pet : battle.otherPets) {
        if (pet.sid == sid && pet.state == 1) return &pet;
    }
    for (const auto& pet : battle.myPets) {
        if (pet.sid == sid) return &pet;
    }
    for (const auto& pet : battle.otherPets) {
        if (pet.sid == sid) return &pet;
    }
    return nullptr;
}

static BattleEntity* FindBattleEntityBySidInTeam(std::vector<BattleEntity>& team, int32_t sid) {
    if (sid == 0) return nullptr;
    // 先找"正在场上"的那只（state == 1）。换宠会在名册里留下离场记录，若同一
    // sid 出现两次（换宠包没匹配到 uniqueid、被当成新妖怪追加到队尾），
    // 先撞到的那只可能是早已下场的旧槽位 —— 回合血量/PP 就全写到它身上，
    // 面板上在场的那只永远不动（“换宠之后被攻击不掉血、技能不减 PP”）。
    // AS3 battleRoundOpration 只拿本次出战的 playerRole/otherRole 比 sid，
    // 从不在整份名册里遍历，这里先按 state == 1 收敛，语义与之一致。
    for (auto& pet : team) {
        if (pet.sid == sid && pet.state == 1) return &pet;
    }
    for (auto& pet : team) {
        if (pet.sid == sid) return &pet;
    }
    return nullptr;
}


static bool BattleTeamHasSid(const std::vector<BattleEntity>& team, int32_t sid) {
    if (sid == 0) return false;
    for (const auto& pet : team) {
        if (pet.sid == sid) return true;
    }
    return false;
}
static bool BattlePetHasSkill(const BattleEntity& pet, int32_t skillId) {
    if (skillId <= 0) return false;
    for (const auto& skill : pet.skills) {
        if (static_cast<int32_t>(skill.id) == skillId) return true;
    }
    return false;
}

static bool BattleTeamHasSkill(const std::vector<BattleEntity>& team, int32_t skillId) {
    for (const auto& pet : team) {
        if (!pet.placeholder && BattlePetHasSkill(pet, skillId)) return true;
    }
    return false;
}

// 敌我两边的 sid 都可能从 1 开始，单靠 sid 会取到我方同号实体。
// 优先用当前出战索引判断阵营；两个阵营同号时这就是唯一可靠的线索。
static bool ResolveBattleSideByActiveSid(const BattleData& battle, int32_t sid, bool& isMySide) {
    if (sid == 0) return false;
    const bool myActive = battle.myActiveIndex >= 0 &&
        battle.myActiveIndex < static_cast<int32_t>(battle.myPets.size()) &&
        battle.myPets[static_cast<size_t>(battle.myActiveIndex)].sid == sid;
    const bool otherActive = battle.otherActiveIndex >= 0 &&
        battle.otherActiveIndex < static_cast<int32_t>(battle.otherPets.size()) &&
        battle.otherPets[static_cast<size_t>(battle.otherActiveIndex)].sid == sid;
    if (myActive != otherActive) {
        isMySide = myActive;
        return true;
    }
    return false;
}

/**
 * @brief 找到状态真正该挂在哪只妖怪身上
 * @details AS3 的判定非常简单（BaseInfoPanel.as:460-521 addBuf / 523-541 delBuf）：
 *          直接把 `defid` 和“我方当前出战那只的 sid”“敌方当前出战那只的 sid”比较。
 *          sid 在一场战斗内是全局唯一的，所以：
 *            1) 先按 sid 找，命中唯一一只就用它 —— 这是唯一权威路径；
 *            2) sid 一个都命中不了，才怀疑封包给的是配置 ID（uniqueId）；
 *            3) defId == 0 表示“施法者自己”，回落到 atkId。
 *          旧实现额外按“这是不是降低类状态”把阵营翻到对面，那是自创启发式：只要
 *          defId 明明已经指定了目标，翻转就会把状态挂到对面那只身上（面板表现为
 *          “自己的增益跑到敌人身上”）。这里去掉翻转，只在真有多只同时命中时才用
 *          “出战优先 / 施法方优先”挑一只。
 */
static BattleEntity* ResolveBufTargetEntity(BattleData& battle, const BufData& buf) {
    auto collect = [](std::vector<BattleEntity>& team, std::vector<BattleEntity*>& out,
                      int32_t key, bool byUnique) {
        if (key == 0) return;
        for (auto& pet : team) {
            if (byUnique ? pet.uniqueId == key : pet.sid == key) out.push_back(&pet);
        }
    };

    auto pickOne = [](std::vector<BattleEntity*>& hits) -> BattleEntity* {
        if (hits.size() == 1) return hits.front();
        for (BattleEntity* pet : hits) {
            if (pet->state == 1) return pet;
        }
        return hits.empty() ? nullptr : hits.front();
    };

    auto lookup = [&](int32_t key, bool byUnique) -> BattleEntity* {
        std::vector<BattleEntity*> hits;
        collect(battle.myPets, hits, key, byUnique);
        collect(battle.otherPets, hits, key, byUnique);
        return pickOne(hits);
    };

    // 1) sid（权威路径）
    if (BattleEntity* pet = lookup(buf.defId, false)) return pet;
    // 2) 封包偶尔给配置 ID
    if (BattleEntity* pet = lookup(buf.defId, true)) return pet;
    // 3) defId 为 0 = 施法者自己（武甲这类自加状态）
    if (buf.defId == 0 && buf.atkId != 0) {
        if (BattleEntity* pet = lookup(buf.atkId, false)) return pet;
    }
    return nullptr;
}

static void ApplyBattleBufToBattle(BattleData& battle, int32_t sid, const BufData& bufData) {
    BufData buf = bufData;
    buf.defId = sid;
    if (BattleEntity* pet = ResolveBufTargetEntity(battle, buf)) {
        ApplyBattleBufToPet(*pet, buf);
    }
}

static void RemoveBattleBufFromBattle(BattleData& battle, int32_t sid, int32_t bufId) {
    // 对齐 AS3 BaseInfoPanel.delBuf(523-541)：它用**两个独立的 if** 比较
    // `playerinfo.sid == defId` 与 `otherinfo.sid == defId`，命中哪边就删哪边。
    // sid 是全局唯一键，正常只会命中一只；旧实现先"二选一"再删，一旦两边都有
    // 同号实体就会漏删（状态永远挂在面板上不掉）。
    bool removed = false;
    if (sid != 0) {
        if (BattleEntity* mine = FindBattleEntityBySidInTeam(battle.myPets, sid)) {
            RemoveBattleBufFromPet(*mine, bufId);
            removed = true;
        }
        if (BattleEntity* theirs = FindBattleEntityBySidInTeam(battle.otherPets, sid)) {
            RemoveBattleBufFromPet(*theirs, bufId);
            removed = true;
        }
    }
    if (removed) return;

    // sid 对不上：可能给的是配置 ID，或者 defId==0（施法者自己）。
    BufData probe;
    probe.defId = sid;
    probe.bufId = bufId;
    if (BattleEntity* target = ResolveBufTargetEntity(battle, probe)) {
        RemoveBattleBufFromPet(*target, bufId);
    }
}

static void AdjustBattleEntityHp(BattleEntity* pet, int32_t delta) {
    if (!pet) return;
    const int64_t nextHp = static_cast<int64_t>(pet->hp) + delta;
    if (nextHp < 0) pet->hp = 0;
    else if (nextHp > pet->maxHp) pet->hp = pet->maxHp;
    else pet->hp = static_cast<int32_t>(nextHp);
}

// 状态/伤害包的 defId 是目标 sid，atkId 是施法者。敌我 sid 重号时不能
// 直接 FindBattleEntityBySid 取第一个：先按当前出战索引判断施法方，再按
// “伤害打对面 / 治疗给自己”的规则取目标阵营。
static BattleEntity* ResolveBattleEffectTarget(BattleData& battle, int32_t defId,
                                                int32_t atkId, bool selfTarget) {
    if (defId == 0) defId = atkId;
    if (defId == 0) return nullptr;
    BattleEntity* my = FindBattleEntityBySidInTeam(battle.myPets, defId);
    BattleEntity* other = FindBattleEntityBySidInTeam(battle.otherPets, defId);
    if (!my && !other) return nullptr;
    if (my && !other) return my;
    if (other && !my) return other;

    bool atkIsMy = false;
    const bool known = ResolveBattleSideByActiveSid(battle, atkId, atkIsMy);
    // defId == atkId 是反伤/自伤类状态，目标必然和施法者同侧。
    if (defId == atkId) return known ? (atkIsMy ? my : other) : my;
    const bool wantMy = known ? (selfTarget ? atkIsMy : !atkIsMy) : true;
    return wantMy ? my : other;
}

static void ApplyBattleBuffBloodEffect(BattleData& battle, const BufData& buf) {
    switch (buf.bufId) {
        case 2: case 9: case 17: case 24: case 29: case 33: case 34: case 59: case 95: case 104: case 113: {
            BattleEntity* target = ResolveBattleEffectTarget(battle, buf.defId, buf.atkId, false);
            AdjustBattleEntityHp(target, -buf.param1);
            if (buf.bufId == 33 && buf.param2 != 0) {
                const BattleEntity* activeMy = battle.myActiveIndex >= 0 && battle.myActiveIndex < static_cast<int32_t>(battle.myPets.size()) ? &battle.myPets[battle.myActiveIndex] : nullptr;
                const BattleEntity* activeOther = battle.otherActiveIndex >= 0 && battle.otherActiveIndex < static_cast<int32_t>(battle.otherPets.size()) ? &battle.otherPets[battle.otherActiveIndex] : nullptr;
                if (activeMy && activeOther) {
                    BattleEntity* reboundTarget = target == activeMy ? &battle.otherPets[battle.otherActiveIndex] : &battle.myPets[battle.myActiveIndex];
                    AdjustBattleEntityHp(reboundTarget, buf.param2);
                }
            }
            break;
        }
        case 36: case 37: case 45: case 46: case 62: case 103: case 9999:
            AdjustBattleEntityHp(ResolveBattleEffectTarget(battle, buf.defId, buf.atkId, true), buf.param1);
            break;
        default:
            break;
    }
}
static void ApplyBattlePpDelta(BattleData& battle, int32_t sid, int32_t atkId,
                               int32_t delta, bool selfTarget) {
    BattleEntity* pet = ResolveBattleEffectTarget(battle, sid, atkId, selfTarget);
    if (!pet) return;
    // 对齐 AS3 handlePPChange(1627-1659)：整只妖怪的**所有技能**一起加减，
    // 结果夹到 [0, maxtime]。maxPp 未知（<=0）时不能当成上限 0 去夹，
    // 否则一次 type3 事件就会把全部技能 PP 清零。
    for (auto& skill : pet->skills) {
        int64_t nextPp = static_cast<int64_t>(skill.pp) + delta;
        if (nextPp < 0) nextPp = 0;
        if (skill.maxPp > 0 && nextPp > skill.maxPp) nextPp = skill.maxPp;
        skill.pp = static_cast<int32_t>(nextPp);
        skill.time = skill.pp;
    }
}
static void ApplyBattleSkillPpDelta(BattleData& battle, int32_t sid, int32_t atkId,
                                   int32_t skillId, int32_t delta) {
    BattleEntity* pet = ResolveBattleEffectTarget(battle, sid, atkId, false);
    if (!pet) return;
    for (auto& skill : pet->skills) {
        if (static_cast<int32_t>(skill.id) != skillId) continue;
        int64_t nextPp = static_cast<int64_t>(skill.pp) + delta;
        if (nextPp < 0) nextPp = 0;
        if (skill.maxPp > 0 && nextPp > skill.maxPp) nextPp = skill.maxPp;
        skill.pp = static_cast<int32_t>(nextPp);
        skill.time = skill.pp;
        return;
    }
}
/**
 * @brief 扣除出手方所用技能的 PP
 * @details AS3 BattleView.deductSkillPP(1925-1939) 的全部语义只有三步：
 *            `if (skillid == skillId && time > 0) { --time;
 *              if (hasDoubleCost && time > 0) --time; break; }`
 *          要点：
 *            1) **time > 0 才扣**（已经是 0 的技能不会被扣成负数，也不会“扣到别的技能上”）；
 *            2) 76 号状态（PP 消耗翻倍）的第二次扣减要再判一次 time > 0；
 *            3) 命中即 break —— 只扣一个技能，不继续找同 id 的后续项。
 *          旧实现没有 time > 0 前置，会把 0 PP 的技能压成负数;同时用 sid 在双方
 *          队伍里"二选一"，同号时会扣到对面那只身上（表现就是"打了半天 PP 一点没变"）。
 */
static bool DecreaseBattleSkillPp(BattleData& battle, int32_t sid, int32_t skillId, bool mySideHint) {
    if (skillId <= 0 || sid == 0) return false;
    BattleEntity* myPet = FindBattleEntityBySidInTeam(battle.myPets, sid);
    BattleEntity* otherPet = FindBattleEntityBySidInTeam(battle.otherPets, sid);
    BattleEntity* pet = nullptr;
    if (myPet != nullptr && otherPet != nullptr) {
        pet = mySideHint ? myPet : otherPet;
    } else {
        pet = myPet != nullptr ? myPet : otherPet;
    }
    if (pet == nullptr) return false;

    const bool doubleCost = BattlePetHasBuf(*pet, 76);
    for (auto& skill : pet->skills) {
        if (static_cast<int32_t>(skill.id) != skillId) continue;
        if (skill.time <= 0) return false;  // AS3: time > 0 才扣
        --skill.time;
        if (doubleCost && skill.time > 0) --skill.time;
        if (skill.time < 0) skill.time = 0;
        if (skill.maxPp > 0 && skill.time > skill.maxPp) skill.time = skill.maxPp;
        skill.pp = skill.time;  // pp 是 UI 展示镜像，必须跟 time 保持一致
        return true;
    }
    return false;
}
static bool ReadBattleEntityAfterState(BoundedReader& reader, int32_t rawState, BattleEntity& pet) {
    pet.rawState = rawState;
    if (!reader.ReadI32(pet.sid) ||
        !reader.ReadI32(pet.groupType) ||
        !reader.ReadI32(pet.hp) ||
        !reader.ReadI32(pet.maxHp) ||
        !reader.ReadI32(pet.level) ||
        !reader.ReadI32(pet.elem) ||
        !reader.ReadI32(pet.spiritId) ||
        !reader.ReadI32(pet.uniqueId) ||
        !reader.ReadI32(pet.userId) ||
        !reader.ReadI32(pet.skillNum)) {
        return false;
    }

    if (pet.skillNum < 0 || pet.skillNum > 128) return false;
    pet.state = (pet.rawState == 2) ? 1 : pet.rawState;
    pet.skills.clear();
    pet.skills.reserve(static_cast<size_t>(pet.skillNum));
    for (int32_t i = 0; i < pet.skillNum; ++i) {
        BattleSkill skill;
        if (!reader.ReadU32(skill.id) ||
            !reader.ReadI32(skill.time) ||
            !reader.ReadI32(skill.maxTime)) {
            return false;
        }
        skill.pp = skill.time;
        skill.maxPp = skill.maxTime;
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            auto it = g_skillNames.find(static_cast<int>(skill.id));
            if (it != g_skillNames.end()) skill.name = it->second;
        }
        pet.skills.push_back(std::move(skill));
    }

    {
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        auto it = g_petNames.find(pet.spiritId);
        if (it != g_petNames.end()) pet.name = it->second;
    }
    return true;
}

static bool HttpGet(const wchar_t* url, std::vector<uint8_t>& out) {
    HINTERNET hInternet = InternetOpenW(L"KBWebUILoader", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (!hInternet) return false;
    HINTERNET hFile = InternetOpenUrlW(hInternet, url, NULL, 0, INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE, 0);
    if (!hFile) { InternetCloseHandle(hInternet); return false; }
    out.clear();
    BYTE buffer[4096];
    DWORD read = 0;
    while (InternetReadFile(hFile, buffer, sizeof(buffer), &read) && read > 0) {
        out.insert(out.end(), buffer, buffer + read);
    }
    InternetCloseHandle(hFile);
    InternetCloseHandle(hInternet);
    return !out.empty();
}

static bool ExtractZipEntry(const std::vector<uint8_t>& zip, const std::string& filename, std::vector<uint8_t>& out) {
    out.clear();

    // 安全检查：zip数据大小
    if (zip.empty() || zip.size() > (100 * 1024 * 1024)) { // 最大100MB
        return false;
    }

    // 使用轻量级ZIP解析器进行纯内存解压
    // 传入inflate函数以支持raw deflate格式（ZIP使用）
    return ExtractZipEntryFromMemory(zip, filename, out, uncompress,
        reinterpret_cast<InflateInit2Func>(inflateInit2_),
        reinterpret_cast<InflateFunc>(inflate),
        reinterpret_cast<InflateEndFunc>(inflateEnd));
}

static std::string NormalizeXmlUtf8(const std::vector<uint8_t>& data) {
    if (data.size() >= 2 && data[0] == 0xFF && data[1] == 0xFE) {
        size_t wc = (data.size() - 2) / 2;
        std::wstring w;
        w.resize(wc);
        memcpy(&w[0], data.data() + 2, wc * 2);
        return WideToUtf8(w);
    }
    if (data.size() >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF) {
        return std::string((const char*)data.data() + 3, data.size() - 3);
    }
    std::string head((const char*)data.data(), data.size() > 256 ? 256 : data.size());
    std::string lower = head;
    for (auto& c : lower) c = (char)tolower((unsigned char)c);
    if (lower.find("encoding=\"gbk\"") != std::string::npos || lower.find("encoding=\"gb2312\"") != std::string::npos) {
        std::string raw((const char*)data.data(), data.size());
        std::wstring w = MultiToWide(raw, 936);
        return WideToUtf8(w);
    }
    return std::string((const char*)data.data(), data.size());
}

static void ParseSpriteXml(const std::string& xml) {
    std::vector<BossInfo> bossList;
    std::vector<std::pair<int, std::wstring>> petNames;
    std::vector<std::pair<int, int>> petElems;

    size_t searchPos = 0;
    size_t contentStart = 0;
    size_t closeStart = 0;
    size_t nextPos = 0;
    std::string startTag;
    while (FindElementBlock(xml, "sprite", searchPos, contentStart, closeStart, nextPos, &startTag)) {
        std::string idText;
        if (!ExtractAttributeValue(startTag, "id", idText)) {
            searchPos = nextPos;
            continue;
        }

        int id = 0;
        if (!TryParseInt(idText, id)) {
            searchPos = nextPos;
            continue;
        }

        std::string content = xml.substr(contentStart, closeStart - contentStart);
        std::wstring name;
        std::string nameText;
        if (ExtractTagValue(content, "name", nameText)) {
            name = Utf8ToWide(nameText);
            TrimTrailingWhitespace(name);
            petNames.emplace_back(id, name);
        }

        int elemId = 0;
        std::string elemText;
        if (ExtractTagValue(content, "elem", elemText)) {
            TryParseInt(elemText, elemId);
            petElems.emplace_back(id, elemId);
        }

        if (id > 10000 && !name.empty()) {
            bossList.push_back({id, name, elemId});
        }

        searchPos = nextPos;
    }

    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    for (const auto& [petId, petName] : petNames) {
        g_petNames[petId] = petName;
    }
    for (const auto& [petId, elemId] : petElems) {
        g_petElems[petId] = elemId;
    }
    g_bossList = std::move(bossList);
}

static void ParseSkillXml(const std::string& xml) {
    std::vector<std::pair<int, std::wstring>> skillNames;
    std::vector<std::pair<int, int>> skillPowers;
    std::vector<std::pair<int, int>> skillRanges;


    size_t searchPos = 0;
    size_t contentStart = 0;
    size_t closeStart = 0;
    size_t nextPos = 0;
    while (FindElementBlock(xml, "skill", searchPos, contentStart, closeStart, nextPos)) {
        const std::string content = xml.substr(contentStart, closeStart - contentStart);
        std::string idText;
        if (!ExtractTagValue(content, "idx", idText)) {
            searchPos = nextPos;
            continue;
        }

        int id = 0;
        if (!TryParseInt(idText, id) || id == 0) {
            searchPos = nextPos;
            continue;
        }

        std::string nameText;
        if (ExtractTagValue(content, "name", nameText)) {
            std::wstring name = Utf8ToWide(nameText);
            TrimTrailingWhitespace(name);
            skillNames.emplace_back(id, std::move(name));
        }

        std::string powerText;
        int power = 0;
        if (ExtractTagValue(content, "power", powerText) && TryParseInt(powerText, power)) {
            skillPowers.emplace_back(id, power);
        }

        int range = 0;
        std::string rangeText;
        if (ExtractTagValue(content, "range", rangeText)) {
            TryParseInt(rangeText, range);
        }
        skillRanges.emplace_back(id, range);
        searchPos = nextPos;
    }


    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    for (const auto& [skillId, skillName] : skillNames) {
        g_skillNames[skillId] = skillName;
    }
    for (const auto& [skillId, power] : skillPowers) {
        g_skillPowers[skillId] = power;
    }
    for (const auto& [skillId, range] : skillRanges) {
        g_skillRanges[skillId] = range;
    }
}



static void ParseMapXml(const std::string& xml) {
    size_t searchPos = 0;
    while (true) {
        size_t tagPos = xml.find('<', searchPos);
        if (tagPos == std::string::npos) {
            break;
        }

        const size_t tagEnd = xml.find('>', tagPos);
        if (tagEnd == std::string::npos) {
            break;
        }

        const std::string tag = xml.substr(tagPos, tagEnd - tagPos + 1);
        if (tag.rfind("<country", 0) == 0 || tag.rfind("<scene", 0) == 0 || tag.rfind("<map", 0) == 0) {
            std::string idText;
            std::string nameText;
            if (ExtractAttributeValue(tag, "id", idText) && ExtractAttributeValue(tag, "name", nameText)) {
                int id = 0;
                if (TryParseInt(idText, id)) {
                    std::wstring name = Utf8ToWide(nameText);
                    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
                    g_mapNames[id] = name;
                }
            }
        }

        searchPos = tagEnd + 1;
    }
}

static void ParseToolXml(const std::string& xml) {
    size_t searchPos = 0;
    size_t contentStart = 0;
    size_t closeStart = 0;
    size_t nextPos = 0;
    std::string startTag;
    while (FindElementBlock(xml, "tool", searchPos, contentStart, closeStart, nextPos, &startTag)) {
        std::string idText;
        std::string nameText;
        if (!ExtractAttributeValue(startTag, "id", idText) || !ExtractTagValue(xml.substr(contentStart, closeStart - contentStart), "name", nameText)) {
            searchPos = nextPos;
            continue;
        }

        int id = 0;
        if (!TryParseInt(idText, id)) {
            searchPos = nextPos;
            continue;
        }
        std::wstring name = Utf8ToWide(nameText);
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        g_toolNames[id] = name;
        searchPos = nextPos;
    }
}

// 解析 Buff 信息 (bufInfo.xml)
static void ParseBufInfoXml(const std::string& xml) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    g_bufNames.clear();
    g_bufDescs.clear();

    size_t searchPos = 0;
    size_t contentStart = 0;
    size_t closeStart = 0;
    size_t nextPos = 0;
    std::string startTag;
    while (FindElementBlock(xml, "bufInfo", searchPos, contentStart, closeStart, nextPos, &startTag)) {
        std::string idText;
        if (!ExtractAttributeValue(startTag, "id", idText)) {
            searchPos = nextPos;
            continue;
        }

        int id = 0;
        if (!TryParseInt(idText, id)) {
            searchPos = nextPos;
            continue;
        }

        std::string content = xml.substr(contentStart, closeStart - contentStart);
        std::string nameText;
        if (ExtractTagValue(content, "name", nameText)) {
            g_bufNames[id] = Utf8ToWide(nameText);
        }

        std::string descText;
        if (ExtractTagValue(content, "combat_desc", descText)) {
            g_bufDescs[id] = Utf8ToWide(descText);
        }

        searchPos = nextPos;
    }
}

// 解析系别和性格数据 (monsternature.xml)
static void ParseMonsterNatureXml(const std::string& xml) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    g_elemNames.clear();
    g_geniusNames.clear();

    std::string elemSection;
    if (FindSectionByType(xml, "1", elemSection)) {
        ParseNamedItemsSection(elemSection, g_elemNames, 0);
    }

    if (g_elemNames.empty()) {
        static const wchar_t* defaultElems[] = {
            L"金", L"木", L"水", L"火", L"土", L"妖", L"魔", L"毒", L"圣",
            L"翼", L"雷", L"幻", L"怪", L"风", L"灵", L"特殊", L"无", L"冰",
            L"机械", L"火风", L"木灵", L"土幻", L"水妖", L"音", L"金怪"
        };
        for (int i = 0; i < 25; i++) {
            g_elemNames[i] = defaultElems[i];
        }
    }

    std::string geniusSection;
    if (FindSectionByType(xml, "0", geniusSection)) {
        ParseNamedItemsSection(geniusSection, g_geniusNames, 1);
    }
    
    // 如果解析失败，使用默认性格表
    if (g_geniusNames.empty()) {
        static const wchar_t* defaultGenius[] = {
            L"", L"孤僻", L"勇敢", L"固执", L"调皮", L"大胆", L"悠闲", L"淘气", L"无虑",
            L"胆小", L"急躁", L"开朗", L"天真", L"保守", L"稳重", L"冷静", L"马虎",
            L"沉着", L"狂妄", L"慎重", L"温顺", L"认真", L"实干", L"平静", L"坦率", L"浮躁"
        };
        for (int i = 1; i <= 25; i++) {
            g_geniusNames[i] = defaultGenius[i];
        }
    }

    // 资质名称 (根据AS3代码 CommonDefine.as 中的 aptLit)
    static const wchar_t* aptitudeLevelNames[] = {
        L"未知资质", L"泛泛之辈", L"璞玉之质", L"百里挑一", L"千载难逢", L"万众瞩目", L"绝代妖王"
    };
    for (int i = 0; i <= 6; i++) {
        g_aptitudeNames[i] = aptitudeLevelNames[i];
    }
}

// 前置声明
static void LoadHttpData();

bool PacketParser::Initialize() {
    std::lock_guard<std::mutex> lifecycleLock(g_parserLifecycleMutex);
    // zlib 已静态链接进 exe（third_party/zlib），不再内存加载 zlib1.dll。

    // 加载HTTP数据
    LoadHttpData();

    return true;
}

void PacketParser::Cleanup() {
    std::lock_guard<std::mutex> lifecycleLock(g_parserLifecycleMutex);
    g_recvBuffer.clear();
    BattleSession::Instance().Reset();
}

bool PacketParser::UncompressBody(const std::vector<uint8_t>& compressed, std::vector<uint8_t>& decompressed) {
    decompressed.clear();
    
    if (compressed.empty()) return false;
    
    // 安全检查：压缩数据大小限制（最大10MB）
    if (compressed.size() > (10 * 1024 * 1024)) return false;
    
    // 尝试多次解压，逐步增加缓冲区大小
    unsigned long destLen = static_cast<unsigned long>(compressed.size() * 4);
    const unsigned long maxDestLen = static_cast<unsigned long>(compressed.size() * 100); // 最大100倍扩展
    
    // 额外安全检查：防止整数溢出
    if (destLen > (50 * 1024 * 1024)) { // 最大解压后50MB
        return false;
    }
    
    int res = -5; // Z_BUF_ERROR
    
    while (destLen <= maxDestLen) {
        decompressed.resize(destLen);
        res = uncompress(decompressed.data(), &destLen, compressed.data(), (unsigned long)compressed.size());
        
        if (res == 0) { // Z_OK
            decompressed.resize(destLen);
            return true;
        }
        
        if (res != -5) { // 不是缓冲区不足错误，直接退出
            break;
        }
        
        // 缓冲区不足，增加大小重试
        unsigned long newDestLen = destLen * 2;
        
        // 检查是否会溢出或超过最大限制
        if (newDestLen < destLen || newDestLen > maxDestLen) {
            break;
        }
        
        destLen = newDestLen;
    }
    
    decompressed.clear();
    return false;
}

bool PacketParser::ParsePackets(const uint8_t* data, size_t size,
                                std::vector<GamePacket>& outPackets,
                                bool* canRewriteInput) {
    outPackets.clear();
    if (canRewriteInput) {
        *canRewriteInput = false;
    }
    if (!data || size == 0) {
        return false;
    }

    struct RawRecvPacket {
        uint16_t magic = 0;
        uint16_t length = 0;
        uint32_t opcode = 0;
        uint32_t params = 0;
        std::vector<uint8_t> rawBody;
    };

    std::vector<RawRecvPacket> rawPackets;
    bool foundAny = false;
    bool hadPendingReceiveBytes = false;
    bool rewritable = false;

    // 生命周期锁只保护 g_recvBuffer 的拼接/切片，zlib 解压放到锁外：
    // Cleanup 不必再等一次大包解压完成。
    {
        std::lock_guard<std::mutex> lifecycleLock(g_parserLifecycleMutex);

        hadPendingReceiveBytes = !g_recvBuffer.empty();

        if (g_recvBuffer.size() + size > kMaxReceiveBufferBytes) {
            std::vector<uint8_t>().swap(g_recvBuffer);
        }
        const size_t newSize = g_recvBuffer.size() + size;
        if (g_recvBuffer.capacity() < newSize) {
            g_recvBuffer.reserve((std::max)(newSize, g_recvBuffer.capacity() * 2));
        }
        g_recvBuffer.insert(g_recvBuffer.end(), data, data + size);

        if (g_recvBuffer.size() >= PacketProtocol::HEADER_SIZE) {
            size_t readOffset = 0;
            const size_t dataSize = g_recvBuffer.size();

            while (readOffset + PacketProtocol::HEADER_SIZE <= dataSize) {
                const uint16_t magic = static_cast<uint16_t>(g_recvBuffer[readOffset]) |
                                       (static_cast<uint16_t>(g_recvBuffer[readOffset + 1]) << 8);
                if (magic != PacketProtocol::MAGIC_NORMAL && magic != PacketProtocol::MAGIC_COMPRESSED) {
                    g_recvBuffer.clear();
                    break;
                }

                const uint16_t bodyLength = static_cast<uint16_t>(g_recvBuffer[readOffset + 2]) |
                                            (static_cast<uint16_t>(g_recvBuffer[readOffset + 3]) << 8);
                const size_t packetSize = PacketProtocol::HEADER_SIZE + bodyLength;
                if (readOffset + packetSize > dataSize) {
                    break;
                }

                RawRecvPacket raw;
                raw.magic = magic;
                raw.opcode = static_cast<uint32_t>(g_recvBuffer[readOffset + 4]) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 5]) << 8) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 6]) << 16) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 7]) << 24);
                raw.params = static_cast<uint32_t>(g_recvBuffer[readOffset + 8]) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 9]) << 8) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 10]) << 16) |
                             (static_cast<uint32_t>(g_recvBuffer[readOffset + 11]) << 24);
                const size_t bodyStart = readOffset + PacketProtocol::HEADER_SIZE;
                const size_t bodyEnd = bodyStart + bodyLength;
                raw.rawBody.assign(g_recvBuffer.begin() + bodyStart,
                                   g_recvBuffer.begin() + bodyEnd);
                rawPackets.push_back(std::move(raw));
                foundAny = true;
                readOffset += packetSize;
            }

            if (readOffset > 0) {
                g_recvBuffer.erase(g_recvBuffer.begin(), g_recvBuffer.begin() + readOffset);
            }
        }

        rewritable = !hadPendingReceiveBytes && foundAny && g_recvBuffer.empty();
    }

    outPackets.reserve(rawPackets.size());
    for (auto& raw : rawPackets) {
        GamePacket packet;
        packet.magic = raw.magic;
        packet.opcode = raw.opcode;
        packet.params = raw.params;
        packet.rawBody = std::move(raw.rawBody);
        packet.body = packet.rawBody;

        if (packet.magic == PacketProtocol::MAGIC_COMPRESSED) {
            std::vector<uint8_t> decompressed;
            if (UncompressBody(packet.body, decompressed)) {
                packet.body = std::move(decompressed);
            }
        }
        outPackets.push_back(std::move(packet));
    }

    if (canRewriteInput) {
        *canRewriteInput = rewritable;
    }
    return foundAny;
}

void PacketParser::SendToUI(const std::wstring& type, const std::wstring& data) {
    if (!AppHost::GetMainWindow()) return;

    // Build JS call: window.addBattleData('type', 'data')
    // 使用 EscapeJsonString 转义字符串，防止特殊字符导致 JavaScript 语法错误
    std::wstring jsCode = L"if(window.addBattleData) { window.addBattleData('" + 
                          UIBridge::EscapeJsonString(type) + L"', '" + 
                          UIBridge::EscapeJsonString(data) + L"'); }";

    UIBridge::Instance().ExecuteJS(jsCode);
}

void PacketParser::SendBossListToUI() {
    // 快照：g_bossList 由数据加载线程重建，这里在 WebView2 回调线程上读，
    // 无锁直接迭代与重分配并发就是读已释放的堆块。
    std::vector<BossInfo> bossSnapshot;
    {
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        bossSnapshot = g_bossList;
    }

    if (bossSnapshot.empty()) return;
    
    if (!AppHost::GetMainWindow()) return;
    
    std::wstring json = L"[";
    for (size_t i = 0; i < bossSnapshot.size(); i++) {
        if (i > 0) json += L",";
        json += L"{\"id\":" + std::to_wstring(bossSnapshot[i].id) +
                L",\"name\":\"" + bossSnapshot[i].name + L"\"}";
    }
    json += L"]";
    
    std::wstring script = L"if(window.initBossList) { window.initBossList(" + json + L"); }";
    UIBridge::Instance().ExecuteJS(script);
}

static bool g_httpDataLoaded = false;

static void LoadHttpData() {
    if (g_httpDataLoaded) return;
    g_httpDataLoaded = true;

    // 从HTTP下载数据
    std::vector<uint8_t> zipbuf;
    if (!HttpGet(L"http://enter.wanwan4399.com/bin-debug/data/data", zipbuf)) {
        ParseMonsterNatureXml("");
        return;
    }

    if (zipbuf.size() < 4 || zipbuf[0] != 'P' || zipbuf[1] != 'K') {
        ParseMonsterNatureXml("");
        return;
    }

    std::vector<uint8_t> entry;

    // 解析sprite.xml
    entry.clear();
    if (ExtractZipEntry(zipbuf, "sprite.xml", entry)) {
        ParseSpriteXml(NormalizeXmlUtf8(entry));
    }

    // 解析skill.xml
    entry.clear();
    if (ExtractZipEntry(zipbuf, "skill.xml", entry)) {
        ParseSkillXml(NormalizeXmlUtf8(entry));
    }

    // 解析tool.xml
    entry.clear();
    if (ExtractZipEntry(zipbuf, "tool.xml", entry)) {
        ParseToolXml(NormalizeXmlUtf8(entry));
    }

    // 解析monsternature.xml
    entry.clear();
    bool natureOk = ExtractZipEntry(zipbuf, "monsternature.xml", entry);
    if (natureOk) {
        ParseMonsterNatureXml(NormalizeXmlUtf8(entry));
    } else {
        ParseMonsterNatureXml("");
    }
    
    // 解析bufInfo.xml (Buff 信息) - 如果之前本地加载失败，再尝试从 ZIP 加载
    {
        bool needLoad = false;
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            needLoad = g_bufNames.empty();
        }
        if (needLoad) {
            entry.clear();
            if (ExtractZipEntry(zipbuf, "bufInfo.xml", entry)) {
                ParseBufInfoXml(NormalizeXmlUtf8(entry));
            }
        }
    }

    // 解析map.xml (地图信息)
    entry.clear();
    if (ExtractZipEntry(zipbuf, "map.xml", entry)) {
        ParseMapXml(NormalizeXmlUtf8(entry));
    }
    
    // BOSS列表会在WebView2页面加载完成后由demo.cpp调用SendBossListToUI发送
}

std::wstring GetMapName(int mapId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    auto it = g_mapNames.find(mapId);
    if (it != g_mapNames.end()) {
        return it->second;
    }
    return L"";
}
int GetSkillPower(int skillId, int fallbackPower) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_skillPowers.find(skillId);
    return it != g_skillPowers.end() ? it->second : fallbackPower;
}

int GetSkillRange(int skillId, int fallbackRange) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_skillRanges.find(skillId);
    return it != g_skillRanges.end() ? it->second : fallbackRange;
}

std::wstring GetPetName(int petId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_petNames.find(petId);
    return it != g_petNames.end() ? it->second : std::wstring();
}

std::wstring GetSkillName(int skillId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_skillNames.find(skillId);
    return it != g_skillNames.end() ? it->second : std::wstring();
}

std::wstring GetElemName(int elemId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_elemNames.find(elemId);
    return it != g_elemNames.end() ? it->second : std::wstring();
}

std::wstring GetGeniusName(int geniusId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_geniusNames.find(geniusId);
    return it != g_geniusNames.end() ? it->second : std::wstring();
}

int GetPetElem(int petId) {
    std::lock_guard<std::mutex> lock(g_dataMapsMutex);
    const auto it = g_petElems.find(petId);
    return it != g_petElems.end() ? it->second : 0;
}

namespace {

void AppendJsonString(std::wstring& out, const std::wstring& value) {
    out += L"\"" + UIBridge::EscapeJsonString(value) + L"\"";
}

void AppendBattleSkillJson(std::wstring& out, const BattleSkill& skill) {
    out += L"{\"id\":" + std::to_wstring(skill.id);
    out += L",\"name\":";
    AppendJsonString(out, skill.name);
    out += L",\"pp\":" + std::to_wstring(skill.pp);
    out += L",\"maxPp\":" + std::to_wstring(skill.maxPp) + L"}";
}

void AppendBattleBufJson(std::wstring& out, const BufData& buf) {
    out += L"{\"bufId\":" + std::to_wstring(buf.bufId);
    out += L",\"name\":";
    AppendJsonString(out, buf.name);
    out += L",\"tipString\":";
    AppendJsonString(out, buf.tipString);
    out += L",\"round\":" + std::to_wstring(buf.round);
    out += L",\"param1\":" + std::to_wstring(buf.param1);
    out += L",\"param2\":" + std::to_wstring(buf.param2);
    out += L",\"param3\":" + std::to_wstring(buf.param3);
    out += L",\"param4\":" + std::to_wstring(buf.param4);
    out += L",\"leftOrRight\":" + std::to_wstring(buf.leftOrRight);
    out += L",\"addOrRemove\":" + std::to_wstring(buf.addOrRemove) + L"}";
}

void AppendBattleEntityJson(std::wstring& out, const BattleEntity& pet) {
    out += L"{\"spiritId\":" + std::to_wstring(pet.spiritId);
    out += L",\"name\":";
    AppendJsonString(out, pet.name);
    out += L",\"sid\":" + std::to_wstring(pet.sid);
    out += L",\"uniqueId\":" + std::to_wstring(pet.uniqueId);
    out += L",\"userId\":" + std::to_wstring(pet.userId);
    out += L",\"groupType\":" + std::to_wstring(pet.groupType);
    out += L",\"state\":" + std::to_wstring(pet.state);
    out += L",\"rawState\":" + std::to_wstring(pet.rawState);
    out += L",\"mNum\":" + std::to_wstring(pet.mNum);
    out += L",\"hasMNum\":" + std::wstring(pet.hasMNum ? L"true" : L"false");
    out += L",\"placeholder\":" + std::wstring(pet.placeholder ? L"true" : L"false");
    out += L",\"hp\":" + std::to_wstring(pet.hp);
    out += L",\"maxHp\":" + std::to_wstring(pet.maxHp);
    out += L",\"level\":" + std::to_wstring(pet.level);
    out += L",\"elem\":" + std::to_wstring(pet.elem);
    out += L",\"skills\":[";
    for (size_t i = 0; i < pet.skills.size(); ++i) {
        if (i) out += L",";
        AppendBattleSkillJson(out, pet.skills[i]);
    }
    out += L"],\"bufArr\":[";
    for (size_t i = 0; i < pet.bufArr.size(); ++i) {
        if (i) out += L",";
        AppendBattleBufJson(out, pet.bufArr[i]);
    }
    out += L"]}";
}

void AppendBattleTeamJson(std::wstring& out, const std::vector<BattleEntity>& team) {
    out += L"[";
    for (size_t i = 0; i < team.size(); ++i) {
        if (i) out += L",";
        AppendBattleEntityJson(out, team[i]);
    }
    out += L"]";
}

/**
 * @brief 把"出战索引"归一成合法值。
 * @details BattleData::myActiveIndex/otherActiveIndex 用 -1 表示"还没确定"。
 *          必须区分"未设置"和"=0"：两者都当作 0 的话，BATTLE_START 里
 *          `state == 1` 的兜底永远失效，UI 就会一直画第 0 只。
 */
int32_t ResolveBattleActiveIndex(const std::vector<BattleEntity>& team, int32_t index) {
    if (index >= 0 && index < static_cast<int32_t>(team.size())) return index;
    for (size_t i = 0; i < team.size(); ++i) {
        if (!team[i].placeholder && team[i].state == 1) return static_cast<int32_t>(i);
    }
    for (size_t i = 0; i < team.size(); ++i) {
        if (!team[i].placeholder) return static_cast<int32_t>(i);
    }
    return -1;  // 空队伍：明确给出"没有出战妖怪"，别退化成 0
}

}  // namespace

void PacketParser::UpdateUIBattleData() {
    // 没有主窗口就没有 WebView2，后面所有 ExecuteJS 都是空转——直接返回。
    if (!AppHost::GetMainWindow()) {
        return;
    }

    uint64_t sessionId = 0;
    const BattleData battle = BattleSession::Instance().Snapshot(&sessionId);

    // 非战斗态只发一条清空指令，不序列化任何实体。
    if (!battle.active) {
        UIBridge::Instance().ExecuteJS(
            L"if(window.clearBattleUI) { window.clearBattleUI(" +
            std::to_wstring(sessionId) + L"); }");
        return;
    }

    std::wstring jsData = L"{";
    jsData += L"\"active\":true";
    jsData += L",\"sessionId\":" + std::to_wstring(sessionId);
    jsData += L",\"myPets\":";
    AppendBattleTeamJson(jsData, battle.myPets);
    jsData += L",\"otherPets\":";
    AppendBattleTeamJson(jsData, battle.otherPets);
    jsData += L",\"myActiveIndex\":" + std::to_wstring(ResolveBattleActiveIndex(battle.myPets, battle.myActiveIndex));
    jsData += L",\"otherActiveIndex\":" + std::to_wstring(ResolveBattleActiveIndex(battle.otherPets, battle.otherActiveIndex));
    jsData += L",\"battleType\":" + std::to_wstring(battle.battleType);
    jsData += L",\"escape\":" + std::to_wstring(battle.escape);
    jsData += L",\"round\":" + std::to_wstring(battle.round);
    jsData += L"}";

    UIBridge::Instance().ExecuteJS(L"if(window.updateBattleUI) { window.updateBattleUI(" + jsData + L"); }");
}

void PacketParser::ProcessLingyuPacket(const GamePacket& packet) {
    if (packet.opcode != Opcode::LINGYU_LIST) return;

    size_t offset = 0;
    ByteReader reader(packet.body, offset);
    const uint8_t* data = packet.body.data();
    size_t size = packet.body.size();

    if (offset + 4 > size) return;
    int32_t backFlag = reader.I32();

    std::vector<LingyuItem> allItems;
    auto mapping = std::unordered_map<int, std::wstring>{
        {25, L"体力"}, {21, L"攻击"}, {22, L"防御"}, {23, L"法术"}, {24, L"抗性"}, {26, L"速度"}, {11, L"威力"}, {12, L"PP"}
    };

    auto readList = [&](size_t& off) {
        ByteReader offReader(data, size, off);
        if (off + 4 > size) return;
        int32_t count = offReader.I32();
        for (int i = 0; i < count; i++) {
            if (off + 12 > size) break;
            LingyuItem item;
            item.symmId = offReader.I32();
            {
                std::lock_guard<std::mutex> lock(g_dataMapsMutex);
                auto it = g_toolNames.find(item.symmId);
                std::wstring name = (it != g_toolNames.end()) ? it->second : L"未知灵玉";
                // Shorten name: e.g., "1级属性灵玉" -> "1级灵玉"
                size_t attrPos = name.find(L"属性");
                if (attrPos != std::wstring::npos) {
                    name.erase(attrPos, 2);
                }
                item.symmName = name;
            }
            item.symmIndex = offReader.I32();
            item.symmFlag = offReader.I32();

            if (off + 2 > size) break;
            uint16_t nameLen = offReader.U16();
            if (off + nameLen > size) break;
            std::string nameUtf8((const char*)(data + off), nameLen);
            item.petName = Utf8ToWide(nameUtf8);
            off += nameLen;

            if (off + 4 > size) break;
            item.symmType = offReader.I32();

            if (off + 4 > size) break;
            int32_t nativeLen = offReader.I32();
            for (int j = 0; j < nativeLen; j++) {
                if (off + 8 > size) break;
                LingyuAttribute attr;
                attr.nativeEnum = offReader.I32();
                attr.nativeValue = offReader.I32();
                auto it = mapping.find(attr.nativeEnum);
                attr.nativeName = (it != mapping.end()) ? it->second : L"未知";
                item.nativeList.push_back(attr);
            }
            allItems.push_back(item);
        }
    };

    if (backFlag == 1) {
        readList(offset);
        readList(offset);
    } else if (backFlag == 2 || backFlag == 3) {
        readList(offset);
    }

    // Convert to JSON and send to UI
    std::wstring jsData = L"{\"backFlag\":" + std::to_wstring(backFlag) + L",\"items\":[";
    for (size_t i = 0; i < allItems.size(); i++) {
        const auto& item = allItems[i];
        jsData += L"{\"symmId\":" + std::to_wstring(item.symmId) +
                  L",\"symmName\":\"" + item.symmName + L"\"" +
                  L",\"symmIndex\":" + std::to_wstring(item.symmIndex) +
                  L",\"symmFlag\":" + std::to_wstring(item.symmFlag) +
                  L",\"petName\":\"" + item.petName + L"\"" +
                  L",\"symmType\":" + std::to_wstring(item.symmType) +
                  L",\"nativeList\":[";
        for (size_t j = 0; j < item.nativeList.size(); j++) {
            const auto& attr = item.nativeList[j];
            jsData += L"{\"nativeEnum\":" + std::to_wstring(attr.nativeEnum) +
                      L",\"nativeValue\":" + std::to_wstring(attr.nativeValue) +
                      L",\"nativeName\":\"" + attr.nativeName + L"\"}";
            if (j < item.nativeList.size() - 1) jsData += L",";
        }
        jsData += L"]}";
        if (i < allItems.size() - 1) jsData += L",";
    }
    jsData += L"]}";

    std::wstring jsCode = L"if(window.updateLingyuUI) { window.updateLingyuUI(" + jsData + L"); }";
    UIBridge::Instance().ExecuteJS(jsCode);
}

void PacketParser::ReplaceCurrentBattle(BattleData battle) {
    BattleSession::Instance().Replace(std::move(battle));
}

void PacketParser::ClearBattleState(bool releaseEntities) {
    // recursive_mutex：ProcessBattlePacketSafe 内部会调本函数，同线程可重入。
    std::lock_guard<std::recursive_mutex> parseLock(g_battleParseMutex);
    BattleSession::Instance().End(releaseEntities);
    UpdateUIBattleData();
}

void PacketParser::ProcessBattlePacketSafe(const GamePacket& packet) {
    // 整包串行化：所有分支都是"取快照 → 改 → 写回"，必须原子完成，
    // 否则两条线程交错会把对方刚算出的血量/状态覆盖掉。
    std::lock_guard<std::recursive_mutex> parseLock(g_battleParseMutex);

    const int32_t params = static_cast<int32_t>(packet.params);
    const uint8_t* data = packet.body.data();
    const size_t size = packet.body.size();

    auto entityLabel = [](const BattleEntity& pet) {
        if (pet.placeholder) return std::wstring(L"待揭示妖怪");
        return pet.name.empty() ? (std::wstring(L"妖怪") + std::to_wstring(pet.spiritId)) : pet.name;
    };
    auto entityLabelBySid = [&](const BattleData& battle, int32_t sid) {
        if (const BattleEntity* pet = FindBattleEntityBySid(battle, sid)) {
            return entityLabel(*pet);
        }
        return sid == 0 ? std::wstring(L"未知妖怪") : (std::wstring(L"妖怪") + std::to_wstring(sid));
    };
    auto skillLabel = [](int32_t skillId) {
        std::lock_guard<std::mutex> lock(g_dataMapsMutex);
        const auto it = g_skillNames.find(skillId);
        return it != g_skillNames.end() ? it->second : (std::wstring(L"技能") + std::to_wstring(skillId));
    };
    auto sendJson = [](const wchar_t* type, const std::wstring& json) {
        PacketParser::SendToUI(type, json);
    };
    auto sendPrompt = [](const wchar_t* type, const std::wstring& prompt) {
        if (!prompt.empty()) PacketParser::SendToUI(type, prompt);
    };
    // side: 1=我方, -1=敌方, 0=未知。sid 重号时必须带阵营，否则会把伤害
    // 写到对面同号妖怪身上（面板表现为一方永远满血、另一方双倍掉血）。
    auto setHpBySid = [](BattleData& battle, int32_t sid, int32_t hp, int side) {
        BattleEntity* my = FindBattleEntityBySidInTeam(battle.myPets, sid);
        BattleEntity* other = FindBattleEntityBySidInTeam(battle.otherPets, sid);
        BattleEntity* pet = nullptr;
        if (side > 0) pet = my ? my : other;
        else if (side < 0) pet = other ? other : my;
        else pet = my ? my : other;
        if (!pet) return;
        // 服务端给的是"结算后的血量"，理论上已经合法；这里仍夹到 [0, maxHp]，
        // 避免异常包把 hp 写成负数/超过上限后 UI 进度条算出怪比例。
        if (pet->maxHp > 0 && hp > pet->maxHp) hp = pet->maxHp;
        if (hp < 0) hp = 0;
        pet->hp = hp;
    };
    if (packet.opcode == Opcode::BATTLE_START) {
        // AS3 的 onBattleStartParse 只在 mParams >= 0 时解析并派发；负值是观战/重放
        // 控制包，不能当成“开场失败”清掉正在进行的战斗。
        if (params < 0) return;

        const int32_t localUserId = static_cast<int32_t>(g_userId.load());
        BattleData parsedBattle;
        bool parsed = false;
        std::function<bool(BoundedReader, int32_t, BattleData)> parseEntities;
        parseEntities = [&](BoundedReader reader, int32_t state, BattleData battle) -> bool {
            if (state == -1) {
                int32_t escape = 0;
                if (!reader.ReadI32(escape) || reader.Remaining() != 0) return false;
                battle.escape = escape;
                parsedBattle = std::move(battle);
                return true;
            }
            if (battle.myPets.size() + battle.otherPets.size() >= 256) return false;

            BattleEntity pet;
            if (!ReadBattleEntityAfterState(reader, state, pet)) return false;
            const bool isMy = localUserId > 0 ? pet.userId == localUserId : pet.groupType == 1;
            pet.mySpirit = isMy;


            BattleData base = std::move(battle);
            auto appendPet = [&](BattleData candidate, const BattleEntity& entity) {
                if (entity.state == 1) {
                    if (entity.mySpirit) {
                        candidate.myActiveIndex = static_cast<int32_t>(candidate.myPets.size());
                    } else {
                        candidate.otherActiveIndex = static_cast<int32_t>(candidate.otherPets.size());
                    }
                }
                if (entity.mySpirit) candidate.myPets.push_back(entity);
                else candidate.otherPets.push_back(entity);
                return candidate;
            };
            auto appendMNumPlaceholders = [](BattleData candidate, const BattleEntity& entity) {
                if (!entity.hasMNum || entity.mNum <= 1) return candidate;
                std::vector<BattleEntity>& team = entity.mySpirit ? candidate.myPets : candidate.otherPets;
                // mNum 来自封包，属不可信输入。旧实现越界时直接返回空的 BattleData{}，
                // 调用方又用 `myPets.empty() && otherPets.empty()` 判失败 —— 但返回空
                // 值的语义是"整场名册丢弃"，等于一个异常 mNum 就把整场战斗抹掉了。
                // 这里改为**截断**：只补到容量上限为止，已解析的名册保持不变。
                const size_t remaining = team.size() < 256 ? 256 - team.size() : 0;
                int64_t placeholderCount = entity.mNum - 1;
                if (placeholderCount > 1024) placeholderCount = 1024;
                if (placeholderCount > static_cast<int64_t>(remaining)) {
                    placeholderCount = static_cast<int64_t>(remaining);
                }
                for (int64_t i = 0; i < placeholderCount; ++i) {
                    BattleEntity placeholder;
                    placeholder.placeholder = true;
                    placeholder.mySpirit = entity.mySpirit;
                    placeholder.groupType = entity.groupType;
                    team.push_back(std::move(placeholder));
                }
                return candidate;
            };
            auto continueWith = [&](BoundedReader nextReader, BattleData candidate) {
                int32_t nextState = 0;
                if (!nextReader.ReadI32(nextState)) return false;
                return parseEntities(nextReader, nextState, std::move(candidate));
            };

            const bool normalMNum = !isMy && pet.rawState == 2;
            if (normalMNum) {
                if (!reader.ReadI32(pet.mNum) || pet.mNum < 0 || pet.mNum > 1024) return false;
                pet.hasMNum = true;
                BattleData candidate = appendMNumPlaceholders(appendPet(std::move(base), pet), pet);
                if (candidate.myPets.empty() && candidate.otherPets.empty()) return false;
                return continueWith(reader, std::move(candidate));
            }

            return continueWith(reader, appendPet(std::move(base), pet));
        };

        BoundedReader reader(data, size);
        int32_t firstState = 0;
        if (!reader.ReadI32(firstState)) {
            ClearBattleState(true);
            return;
        }
        BattleData initial;
        initial.battleType = params;
        initial.active = true;
        parsed = parseEntities(reader, firstState, std::move(initial));
        if (!parsed) {
            // 新一场开场解析失败时，旧战斗快照不能继续挂在面板上。
            ClearBattleState(true);
            return;
        }

        // 开场包里带 state==1 的才是出战那只；一只都没标（某些活动战斗）时按
        // "首个非占位"归一，保证下游永远拿到合法索引而不是 -1。
        parsedBattle.myActiveIndex =
            ResolveBattleActiveIndex(parsedBattle.myPets, parsedBattle.myActiveIndex);
        parsedBattle.otherActiveIndex =
            ResolveBattleActiveIndex(parsedBattle.otherPets, parsedBattle.otherActiveIndex);

        BattleSession::Instance().Begin(std::move(parsedBattle));
        UpdateUIBattleData();

        const BattleData battle = GetCurrentBattleSnapshot();
        BattleActivity::SyncAutoBattle(battle, true);
        std::wstring myName;
        std::wstring otherName;
        if (battle.myActiveIndex >= 0 &&
            battle.myActiveIndex < static_cast<int32_t>(battle.myPets.size())) {
            myName = entityLabel(battle.myPets[battle.myActiveIndex]);
        }
        if (battle.otherActiveIndex >= 0 &&
            battle.otherActiveIndex < static_cast<int32_t>(battle.otherPets.size())) {
            otherName = entityLabel(battle.otherPets[battle.otherActiveIndex]);
        }
        sendJson(L"战斗开始", L"{\"battleType\":" + std::to_wstring(params) +
                 L",\"escape\":" + std::to_wstring(battle.escape) +
                 L",\"my\":\"" + UIBridge::EscapeJsonString(myName) +
                 L"\",\"other\":\"" + UIBridge::EscapeJsonString(otherName) + L"\"}");
        sendPrompt(L"战斗开始", L"我方" + myName + L" vs 敌方" + otherName);
        return;
    }

    if (packet.opcode == Opcode::BATTLE_ROUND_START) {
        BattleData next = GetCurrentBattleSnapshot();
        if (!next.active) return;
        ++next.round;
        const int32_t roundNumber = next.round;
        next.roundChangeSids.clear();
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();
        BattleActivity::NotifyRoundStart();
        sendJson(L"回合开始", L"{\"round\":" + std::to_wstring(roundNumber) +
                 L",\"params\":" + std::to_wstring(params) + L"}");
        sendPrompt(L"回合开始", L"第" + std::to_wstring(roundNumber) + L"回合开始");
        return;
    }

    if (packet.opcode == Opcode::BATTLE_CHANGE_SPIRIT_ROUND) {
        if (params < 0 || params > 128) return;
        BoundedReader reader(data, size);
        std::vector<int32_t> sids;
        sids.reserve(static_cast<size_t>(params));
        for (int32_t i = 0; i < params; ++i) {
            int32_t sid = 0;
            if (!reader.ReadI32(sid)) return;
            sids.push_back(sid);
        }
        int32_t waitTime = 0;
        if (!reader.ReadI32(waitTime)) return;

        BattleData next = GetCurrentBattleSnapshot();
        next.roundChangeSids = std::move(sids);
        ++next.round;
        const int32_t roundNumber = next.round;
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();
        BattleActivity::NotifyRoundStart();
        sendJson(L"回合开始", L"{\"changeCount\":" + std::to_wstring(params) +
                 L",\"round\":" + std::to_wstring(roundNumber) +
                 L",\"waitTime\":" + std::to_wstring(waitTime) + L"}");
        sendPrompt(L"回合开始", L"进入换宠回合，等待" + std::to_wstring(waitTime) + L"毫秒");
        return;
    }

    if (packet.opcode == Opcode::BATTLE_BUF) {
        BoundedReader reader(data, size);
        BufData buf;
        if (!reader.ReadI32(buf.addOrRemove) || !reader.ReadI32(buf.bufId) ||
            !reader.ReadI32(buf.defId) || !reader.ReadI32(buf.param1) ||
            !reader.ReadI32(buf.param2)) {
            return;
        }
        // BUF_TYPE_7 的两个附加字段只存在于部分客户端版本（MainGame_remote 的
        // onBattleBuf 有 `case BUF_TYPE_7: param3/param4`，主线 MainGame 那版
        // 没有这一支，只读 5 个 int）。旧的固定读法在主线包上必然读空 → 整个
        // 状态包被 return 丢掉，表现就是“加了状态但面板不显示/不褪色”。
        // 这里改成按剩余字节判定：够就解析，不够就当作没有这两个字段。
        if (buf.addOrRemove == BufDataType::BUF_TYPE_7 && reader.Remaining() >= sizeof(int32_t) * 2) {
            if (!reader.ReadI32(buf.param3) || !reader.ReadI32(buf.param4)) return;
        }
        buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
        buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);

        BattleData next = GetCurrentBattleSnapshot();
        const std::wstring targetName = entityLabelBySid(next, buf.defId != 0 ? buf.defId : buf.atkId);
        if (buf.addOrRemove == BufDataType::BUF_TYPE_0) {
            RemoveBattleBufFromBattle(next, buf.defId, buf.bufId);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_1 ||
                   buf.addOrRemove == BufDataType::BUF_TYPE_7) {
            ApplyBattleBufToBattle(next, buf.defId, buf);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_2) {
            ApplyBattleBufToBattle(next, buf.defId, buf);
            ApplyBattleBuffBloodEffect(next, buf);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_4) {
            AdjustBattleEntityHp(ResolveBattleEffectTarget(next, buf.defId, buf.atkId, false), -buf.param1);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_5) {
            AdjustBattleEntityHp(ResolveBattleEffectTarget(next, buf.defId, buf.atkId, true), buf.param1);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_3) {
            ApplyBattlePpDelta(next, buf.defId, buf.atkId, -buf.param1, false);
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_6) {
            ApplyBattlePpDelta(next, buf.defId, buf.atkId, buf.param1, true);
        }
        BattleActivity::SyncAutoBattle(next, false);
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();

        const wchar_t* eventType = buf.addOrRemove == BufDataType::BUF_TYPE_4 ? L"战斗血量事件" :
                                    (buf.addOrRemove == BufDataType::BUF_TYPE_5 ? L"战斗恢复事件" : L"战斗状态");
        sendJson(eventType,
                 L"{\"addOrRemove\":" + std::to_wstring(buf.addOrRemove) +
                 L",\"bufId\":" + std::to_wstring(buf.bufId) +
                 L",\"defId\":" + std::to_wstring(buf.defId) +
                 L",\"param1\":" + std::to_wstring(buf.param1) +
                 L",\"param2\":" + std::to_wstring(buf.param2) +
                 L",\"param3\":" + std::to_wstring(buf.param3) +
                 L",\"param4\":" + std::to_wstring(buf.param4) + L"}");
        std::wstring prompt;
        if (buf.addOrRemove == BufDataType::BUF_TYPE_0) {
            prompt = targetName + L"移除状态：" + buf.name;
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_4) {
            prompt = targetName + L"发生血量变化：" + buf.name;
        } else if (buf.addOrRemove == BufDataType::BUF_TYPE_5) {
            prompt = targetName + L"恢复状态：" + buf.name;
        } else {
            prompt = targetName + L"状态变化：" + buf.name;
            if (buf.round > 0) prompt += L"（" + std::to_wstring(buf.round) + L"回合）";
        }
        sendPrompt(eventType, prompt);
        return;
    }

    if (packet.opcode == Opcode::BATTLE_BUF_DIS) {
        BoundedReader reader(data, size);
        int32_t bufId = 0;
        int32_t defId = 0;
        if (!reader.ReadI32(bufId) || !reader.ReadI32(defId)) return;
        BattleData next = GetCurrentBattleSnapshot();
        const std::wstring targetName = entityLabelBySid(next, defId);
        const std::wstring bufName = GetBufName(bufId);
        RemoveBattleBufFromBattle(next, defId, bufId);
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();
        sendJson(L"战斗状态", L"{\"addOrRemove\":0,\"bufId\":" + std::to_wstring(bufId) +
                 L",\"defId\":" + std::to_wstring(defId) + L"}");
        sendPrompt(L"战斗状态", targetName + L"移除状态：" + bufName);
        return;
    }

    if (packet.opcode == Opcode::BATTLE_BUFS) {
        BoundedReader reader(data, size);
        BattleData next = GetCurrentBattleSnapshot();
        int32_t sid = 0;
        if (!reader.ReadI32(sid)) return;
        int count = 0;
        std::wstring bulkTip;
        while (sid != -1 && sid < 1000) {
            if (++count > 1024) return;
            BufData buf;
            buf.defId = sid;
            buf.addOrRemove = BufDataType::BUF_TYPE_1;
            if (!reader.ReadI32(buf.bufId) || !reader.ReadI32(buf.param1) ||
                !reader.ReadI32(buf.param2)) return;
            buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
            buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);
            if (!bulkTip.empty()) bulkTip += L"，";
            bulkTip += entityLabelBySid(next, buf.defId) + L"：" + buf.name;
            ApplyBattleBufToBattle(next, buf.defId, buf);
            if (!reader.ReadI32(sid)) return;
        }
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();
        sendJson(L"战斗状态", L"{\"bulkCount\":" + std::to_wstring(count) + L"}");
        sendPrompt(L"战斗状态", bulkTip.empty() ? L"状态同步完成" : L"状态同步：" + bulkTip);
        return;
    }

    if (packet.opcode == Opcode::BATTLE_ROUND) {
        if (params < 0 || params > 5) return;
        BattleData next = GetCurrentBattleSnapshot();
        BattleRoundData round;
        round.cmdType = params;
        BoundedReader reader(data, size);

        bool ppApplied = false;
        if (params == 0) {
            if (!reader.ReadI32(round.haveBattle)) return;
            if (round.haveBattle == 1) {
                if (!reader.ReadI32(round.atkId) || !reader.ReadI32(round.skillId) ||
                    !reader.ReadI32(round.defId) || !reader.ReadI32(round.miss)) return;
                bool atkIsMySide = false;
                bool atkSideKnown = false;
                // 先用 sid 判阵营：sid 是服务端按妖怪配置编码出的战斗编号，
                // 正常一场里不会重号，比技能表可靠。技能表只作为最后兜底——
                // 双方可能都带同一个低级技能，先看技能会把敌方出手误判成我方，
                // 表现就是“敌方攻击扣我方血、我方攻击扣敌方血”。
                if (ResolveBattleSideByActiveSid(next, round.atkId, atkIsMySide)) {
                    atkSideKnown = true;
                }
                if (!atkSideKnown) {
                    const bool myHasSid = BattleTeamHasSid(next.myPets, round.atkId);
                    const bool otherHasSid = BattleTeamHasSid(next.otherPets, round.atkId);
                    if (myHasSid != otherHasSid) {
                        atkIsMySide = myHasSid;
                        atkSideKnown = true;
                    }
                }
                if (!atkSideKnown) {
                    // 只有 sid 在双方都出现（重号）时，才用技能归属消歧。
                    const bool myActiveHasSkill =
                        next.myActiveIndex >= 0 &&
                        next.myActiveIndex < static_cast<int32_t>(next.myPets.size()) &&
                        BattlePetHasSkill(next.myPets[static_cast<size_t>(next.myActiveIndex)], round.skillId);
                    const bool otherActiveHasSkill =
                        next.otherActiveIndex >= 0 &&
                        next.otherActiveIndex < static_cast<int32_t>(next.otherPets.size()) &&
                        BattlePetHasSkill(next.otherPets[static_cast<size_t>(next.otherActiveIndex)], round.skillId);
                    if (myActiveHasSkill != otherActiveHasSkill) {
                        atkIsMySide = myActiveHasSkill;
                        atkSideKnown = true;
                    }
                }
                if (!atkSideKnown) {
                    const bool myTeamHasSkill = BattleTeamHasSkill(next.myPets, round.skillId);
                    const bool otherTeamHasSkill = BattleTeamHasSkill(next.otherPets, round.skillId);
                    if (myTeamHasSkill != otherTeamHasSkill) {
                        atkIsMySide = myTeamHasSkill;
                        atkSideKnown = true;
                    }
                }
                if (!atkSideKnown) {
                    atkIsMySide = next.myActiveIndex >= 0 &&
                        next.myActiveIndex < static_cast<int32_t>(next.myPets.size()) &&
                        next.myPets[static_cast<size_t>(next.myActiveIndex)].sid == round.atkId;
                }
                if (round.miss == 0) {
                    if (!reader.ReadI32(round.brust) || !reader.ReadI32(round.atkHp) ||
                        !reader.ReadI32(round.defHp) || !reader.ReadI32(round.reboundHp)) return;
                    setHpBySid(next, round.atkId, round.atkHp, atkIsMySide ? 1 : -1);
                    setHpBySid(next, round.defId, round.defHp,
                                round.defId == round.atkId ? (atkIsMySide ? 1 : -1) : (atkIsMySide ? -1 : 1));
                }
                ppApplied = DecreaseBattleSkillPp(next, round.atkId, round.skillId, atkIsMySide);
            }

            int32_t haveBuf = 0;
            if (!reader.ReadI32(haveBuf)) return;
            while (haveBuf != 0) {
                if (haveBuf < 0) return;
                BufData buf;
                buf.bufId = haveBuf;
                if (!reader.ReadI32(buf.addOrRemove)) return;
                switch (buf.addOrRemove) {
                    case BufDataType::BUF_TYPE_0:
                        if (!reader.ReadI32(buf.defId)) return;
                        buf.name = GetBufName(buf.bufId);
                        buf.tipString = GetBufTipString(buf.bufId, 0, 0);
                        RemoveBattleBufFromBattle(next, buf.defId, buf.bufId);
                        round.bufs.push_back(buf);
                        break;
                    case BufDataType::BUF_TYPE_1:
                        if (!reader.ReadI32(buf.atkId) || !reader.ReadI32(buf.defId) ||
                            !reader.ReadI32(buf.round) || !reader.ReadI32(buf.param1) ||
                            !reader.ReadI32(buf.param2)) return;
                        buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
                        buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);
                        ApplyBattleBufToBattle(next, buf.defId, buf);
                        round.bufs.push_back(buf);
                        break;
                    case BufDataType::BUF_TYPE_2:
                        if (!reader.ReadI32(buf.atkId) || !reader.ReadI32(buf.defId) ||
                            !reader.ReadI32(buf.param1) || !reader.ReadI32(buf.param2)) return;
                        buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
                        buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);
                        ApplyBattleBufToBattle(next, buf.defId, buf);
                        ApplyBattleBuffBloodEffect(next, buf);
                        round.bufs.push_back(buf);
                        break;
                    case BufDataType::BUF_TYPE_3:
                    case BufDataType::BUF_TYPE_6: {
                        int32_t value = 0;
                        if (!reader.ReadI32(value)) return;
                        BattleRoundAppend append;
                        append.type = buf.addOrRemove;
                        append.paramKey = static_cast<int32_t>(buf.bufId);
                        append.paramValue = value;
                        ApplyBattlePpDelta(next, round.defId, round.atkId,
                                           buf.addOrRemove == BufDataType::BUF_TYPE_3 ? -value : value,
                                           buf.addOrRemove == BufDataType::BUF_TYPE_6);
                        // AS3 does not carry a target SID for append entries.
                        round.appends.push_back(append);
                        break;
                    }
                    case BufDataType::BUF_TYPE_4: {
                        BattleRoundAppend append;
                        append.type = buf.addOrRemove;
                        append.paramKey = static_cast<int32_t>(buf.bufId);
                        if (!reader.ReadI32(append.skillId) || !reader.ReadI32(append.paramValue)) return;
                        buf.param1 = append.paramValue;
                        buf.name = GetBufName(buf.bufId);
                        if (append.paramKey == 1) {
                            ApplyBattleSkillPpDelta(next, round.defId, round.atkId, append.skillId, -append.paramValue);
                        }
                        round.appends.push_back(append);
                        round.bufs.push_back(buf);
                        break;
                    }
                    case BufDataType::BUF_TYPE_5:
                        // AS3 has no payload read for type 5; it is retained in bufArr.
                        buf.name = GetBufName(buf.bufId);
                        round.bufs.push_back(buf);
                        break;
                    default:
                        // AS3 的回合解析 switch 里只有 0/1/2/3/4/6 六种，未知类型
                        // **一个字段都不读**然后继续循环（BattleModel.as:313-349）。
                        // 旧实现直接 return，等于把整个回合包丢掉：连后面的
                        // haveBuf 列表和 bufArr 都不生效，表现就是“这一回合的攻击/
                        // 状态全都没更新”。这里对齐 AS3：不收 body、只记录，继续读。
                        buf.name = GetBufName(buf.bufId);
                        round.bufs.push_back(buf);
                        break;
                }
                if (!reader.ReadI32(haveBuf)) return;
            }
        } else if (params == 1) {
            if (!reader.ReadI32(round.sid) || !reader.ReadI32(round.uniqueId) ||
                !reader.ReadI32(round.sta)) return;

            // ---- BATTLE_ROUND params==1 的权威语义（BattleModel.as:357-385）----
            //   round.sid      = 离场（= 当前出战）那只的 sid
            //   round.uniqueId = 进场那只的 uniqueId
            //   sta == 1 时后面再跟一整只实体（state,sid,groupType,hp,...,skills[]）
            // 旧实现把 uniqueId 当成“旧实体”，又拿 round.sid 去找进场槽位 —— 而 sid
            // 正好指向离场那只，于是 found 落到离场槽位、activeIndex 不变，面板一直显示
            // 离场宠的血量/PP/状态。这里整段按 AS3 重写，名册副作用交给
            // BattleRoster::ApplySwitch（有单测覆盖）。
            const int32_t localUserId = static_cast<int32_t>(g_userId.load());
            if (round.sta == 1) {
                int32_t rawState = 0;
                if (!reader.ReadI32(rawState)) return;
                if (!ReadBattleEntityAfterState(reader, rawState, round.switchEntity)) return;
                round.hasSwitchEntity = true;
            }

            // 进场键只认三元组里的 uniqueid（packet_parser.cpp:2203 读的第二个字段）。
            // AS3 dealChangeSpirit 拿 this.boobj.uniqueid 去 playerRoleArr 里比对，
            // boobj 就是这份 "sid, uniqueid, sta" 三元组；实体里的 uniqueId 不参与
            // 匹配。反过来优先用实体值时，一旦两者不同就会匹配不到名册里那只，
            // 于是被当成新妖怪追加到队尾 —— 面板上确实换成了新妖怪，但回合结算
            // 仍按 sid 找到那份已经离场的旧副本，PP 与血量就永远不动了。
            int32_t enteringUniqueId = round.uniqueId;
            if (enteringUniqueId == 0 && round.hasSwitchEntity) {
                enteringUniqueId = round.switchEntity.uniqueId;
            }
            const int32_t enteringUserId = round.hasSwitchEntity ? round.switchEntity.userId : 0;
            const int32_t enteringGroupType = round.hasSwitchEntity ? round.switchEntity.groupType : 0;

            const BattleRoster::Side side = BattleRoster::ResolveSwitchSide(
                next, round.sid, enteringUniqueId, enteringUserId, localUserId, enteringGroupType);
            if (side == BattleRoster::Side::Unknown) {
                // 一条线索都对不上（例如还没收到 BATTLE_START 就来了换宠包）：
                // 宁可什么都不改，也不要把这只妖怪写进对面名册。
                return;
            }

            BattleRoster::ApplySwitch(next, side, round.sid, enteringUniqueId,
                                      round.hasSwitchEntity ? &round.switchEntity : nullptr);
            if (round.hasSwitchEntity) {
                round.switchEntity.mySpirit = (side == BattleRoster::Side::My);
            }
        } else if (params == 2) {
            if (!reader.ReadI32(round.atkId) || !reader.ReadI32(round.itemId) ||
                !reader.ReadI32(round.defId) || !reader.ReadI32(round.param0) ||
                !reader.ReadI32(round.param1)) return;
            if ((round.itemId & 64) != 0 && round.param0 == 1) {
                int32_t* fields[] = {
                    &round.catchData.spiritId, &round.catchData.spiritType, &round.catchData.spiritHp,
                    &round.catchData.spiritAtk, &round.catchData.spiritDef, &round.catchData.spiritMagAtk,
                    &round.catchData.spiritMagDef, &round.catchData.spiritSpeed, &round.catchData.spiritLevel,
                    &round.catchData.spiritSid, &round.catchData.spiritPackId, &round.catchData.spiritSex,
                    &round.catchData.attackGeniusValue, &round.catchData.defenceGeniusValue,
                    &round.catchData.magicGeniusValue, &round.catchData.resistanceGeniusValue,
                    &round.catchData.hpGeniusValue, &round.catchData.speedGeniusValue
                };
                for (int32_t* field : fields) if (!reader.ReadI32(*field)) return;
                round.hasCatchData = true;
            }
        } else if (params == 3) {
            if (!reader.ReadI32(round.atkId) || !reader.ReadI32(round.avail)) return;
        } else if (params == 5) {
            if (!reader.ReadI32(round.status) ||
                (round.status != 1 && round.status != 2)) {
                // The AS3 client only dispatches the two documented restriction codes.
                return;
            }
        }

        std::wstring roundPrompt;
        if (params == 0) {
            if (round.haveBattle == 1) {
                const std::wstring atkName = entityLabelBySid(next, round.atkId);
                const std::wstring defName = entityLabelBySid(next, round.defId);
                const std::wstring skillName = skillLabel(round.skillId);
                if (round.miss != 0) {
                    roundPrompt = defName + L"闪避了" + atkName + L"的" + skillName;
                } else {
                    roundPrompt = atkName + L"使用" + skillName + L"，" + defName +
                                  L"当前生命：" + std::to_wstring(round.defHp);
                    if (const BattleEntity* target = FindBattleEntityBySid(next, round.defId)) {
                        roundPrompt += L"/" + std::to_wstring(target->maxHp);
                    }
                }
            } else {
                roundPrompt = L"本回合没有发生攻击";
            }
            for (const auto& buf : round.bufs) {
                if (!roundPrompt.empty()) roundPrompt += L"；";
                // defId 为 0 表示"施法者自己"（武甲这类自加状态），提示里别写成"未知妖怪"
                const std::wstring targetName = entityLabelBySid(next, buf.defId != 0 ? buf.defId : buf.atkId);
                if (buf.addOrRemove == BufDataType::BUF_TYPE_0) {
                    roundPrompt += targetName + L"移除状态：" + buf.name;
                } else {
                    roundPrompt += targetName + L"状态变化：" + buf.name;
                    if (buf.round > 0) roundPrompt += L"（" + std::to_wstring(buf.round) + L"回合）";
                }
            }
            if (!round.appends.empty()) {
                if (!roundPrompt.empty()) roundPrompt += L"；";
                roundPrompt += L"战斗附加数据已由服务端更新";
            }
        } else if (params == 1) {
            // AS3 BattleModel.as:357-360：sid 是离场那只，uniqueid 才是进场那只。
            // 提示里写“谁上场”，不能再拿离场 sid 当上场妖怪的名字。
            const std::wstring leavingName = entityLabelBySid(next, round.sid);
            const BattleEntity* entering = round.hasSwitchEntity
                ? &round.switchEntity
                : FindBattleEntityByUniqueId(next, round.uniqueId);
            if (entering) {
                roundPrompt = std::wstring(entering->mySpirit ? L"我方" : L"敌方") +
                              L"换上" + entityLabel(*entering) + L"，" + leavingName + L"下场";
            } else {
                roundPrompt = leavingName + L"下场";
            }
        } else if (params == 2) {
            std::wstring itemName;
            {
                std::lock_guard<std::mutex> lock(g_dataMapsMutex);
                const auto it = g_toolNames.find(round.itemId);
                if (it != g_toolNames.end()) itemName = it->second;
            }
            if (itemName.empty()) itemName = L"道具" + std::to_wstring(round.itemId);
            roundPrompt = entityLabelBySid(next, round.atkId) + L"使用" + itemName +
                          L"作用于" + entityLabelBySid(next, round.defId);
            if (round.hasCatchData) roundPrompt += L"，捕捉数据已返回";
        } else if (params == 3) {
            roundPrompt = entityLabelBySid(next, round.atkId) + L"的战斗操作状态为" +
                          (round.avail != 0 ? L"可用" : L"不可用");
        } else if (params == 5) {
            roundPrompt = round.status == 1 ? L"该场战斗不能使用培元金丹" :
                          L"你已使用6次药剂，无法再使用";
        }

        next.lastRound = round;
        BattleActivity::SyncAutoBattle(next, false);
        ReplaceCurrentBattle(std::move(next));
        UpdateUIBattleData();

        std::wstring event = L"{\"cmdType\":" + std::to_wstring(params);
        if (params == 0) {
            event += L",\"haveBattle\":" + std::to_wstring(round.haveBattle) +
                     L",\"atkId\":" + std::to_wstring(round.atkId) +
                     L",\"skillId\":" + std::to_wstring(round.skillId) +
                     L",\"defId\":" + std::to_wstring(round.defId) +
                     L",\"miss\":" + std::to_wstring(round.miss) +
                     L",\"atkHp\":" + std::to_wstring(round.atkHp) +
                     L",\"defHp\":" + std::to_wstring(round.defHp);
        } else if (params == 1) {
            event += L",\"sid\":" + std::to_wstring(round.sid) +
                     L",\"uniqueId\":" + std::to_wstring(round.uniqueId) +
                     L",\"sta\":" + std::to_wstring(round.sta);
        } else if (params == 2) {
            event += L",\"atkId\":" + std::to_wstring(round.atkId) +
                     L",\"itemId\":" + std::to_wstring(round.itemId) +
                     L",\"defId\":" + std::to_wstring(round.defId) +
                     L",\"param0\":" + std::to_wstring(round.param0) +
                     L",\"param1\":" + std::to_wstring(round.param1);
            if (round.hasCatchData) {
                const BattleCatchData& catchData = round.catchData;
                event += L",\"catchData\":{\"spiritId\":" + std::to_wstring(catchData.spiritId) +
                         L",\"spiritType\":" + std::to_wstring(catchData.spiritType) +
                         L",\"spiritHp\":" + std::to_wstring(catchData.spiritHp) +
                         L",\"spiritAtk\":" + std::to_wstring(catchData.spiritAtk) +
                         L",\"spiritDef\":" + std::to_wstring(catchData.spiritDef) +
                         L",\"spiritMagAtk\":" + std::to_wstring(catchData.spiritMagAtk) +
                         L",\"spiritMagDef\":" + std::to_wstring(catchData.spiritMagDef) +
                         L",\"spiritSpeed\":" + std::to_wstring(catchData.spiritSpeed) +
                         L",\"spiritLevel\":" + std::to_wstring(catchData.spiritLevel) +
                         L",\"spiritSid\":" + std::to_wstring(catchData.spiritSid) +
                         L",\"spiritPackId\":" + std::to_wstring(catchData.spiritPackId) +
                         L",\"spiritSex\":" + std::to_wstring(catchData.spiritSex) +
                         L",\"attackGeniusValue\":" + std::to_wstring(catchData.attackGeniusValue) +
                         L",\"defenceGeniusValue\":" + std::to_wstring(catchData.defenceGeniusValue) +
                         L",\"magicGeniusValue\":" + std::to_wstring(catchData.magicGeniusValue) +
                         L",\"resistanceGeniusValue\":" + std::to_wstring(catchData.resistanceGeniusValue) +
                         L",\"hpGeniusValue\":" + std::to_wstring(catchData.hpGeniusValue) +
                         L",\"speedGeniusValue\":" + std::to_wstring(catchData.speedGeniusValue) + L"}";
            }
        } else if (params == 3) {
            event += L",\"atkId\":" + std::to_wstring(round.atkId) +
                     L",\"avail\":" + std::to_wstring(round.avail);
        } else if (params == 5) {
            event += L",\"status\":" + std::to_wstring(round.status);
        }
        if (params == 0 && round.haveBattle == 1) {
            // 便于排查"PP 没扣"：把本次扣 PP 的目标与结果一起带进日志
            event += L",\"ppSid\":" + std::to_wstring(round.atkId) +
                     L",\"ppSkill\":" + std::to_wstring(round.skillId) +
                     L",\"ppApplied\":" + std::wstring(ppApplied ? L"true" : L"false");
        }
        if (!round.bufs.empty()) {
            event += L",\"bufs\":[";
            for (size_t i = 0; i < round.bufs.size(); ++i) {
                if (i) event += L",";
                const auto& buf = round.bufs[i];
                event += L"{\"bufId\":" + std::to_wstring(buf.bufId) +
                         L",\"addOrRemove\":" + std::to_wstring(buf.addOrRemove) +
                         L",\"atkId\":" + std::to_wstring(buf.atkId) +
                         L",\"defId\":" + std::to_wstring(buf.defId) +
                         L",\"round\":" + std::to_wstring(buf.round) +
                         L",\"param1\":" + std::to_wstring(buf.param1) +
                         L",\"param2\":" + std::to_wstring(buf.param2) +
                         L",\"param3\":" + std::to_wstring(buf.param3) +
                         L",\"param4\":" + std::to_wstring(buf.param4) + L"}";
            }
            event += L"]";
        }
        if (!round.appends.empty()) {
            event += L",\"appends\":[";
            for (size_t i = 0; i < round.appends.size(); ++i) {
                if (i) event += L",";
                const auto& append = round.appends[i];
                event += L"{\"type\":" + std::to_wstring(append.type) +
                         L",\"paramKey\":" + std::to_wstring(append.paramKey) +
                         L",\"paramValue\":" + std::to_wstring(append.paramValue) +
                         L",\"skillId\":" + std::to_wstring(append.skillId) + L"}";
            }
            event += L"]";
        }
        event += L"}";
        const wchar_t* eventType = params == 1 ? L"切换宠物" :
                                    (params == 2 ? L"使用道具" : (params == 5 ? L"战斗限制" : L"回合"));
        sendJson(eventType, event);
        sendPrompt(eventType, roundPrompt);
        return;
    }

    if (packet.opcode == Opcode::BATTLE_END) {
        // 先把战场标志清掉并推给 UI，再去解析结算明细：
        // 退出战斗时 body 可能一条结算都没有（逃跑、被中断、body 解码失败），
        // 旧代码在明细解析失败时直接 return，战斗面板就永远挂着上一场的数据。
        ClearBattleState(false);

        BoundedReader reader(data, size);
        std::vector<BattleEndResult> results;
        if (params == 1) {
            int32_t count = 0;
            if (reader.ReadI32(count) && count >= 0 && count <= 1024) {
                results.reserve(static_cast<size_t>(count));
                for (int32_t i = 0; i < count; ++i) {
                    BattleEndResult result;
                    if (!reader.ReadI32(result.sid) || !reader.ReadI32(result.result)) break;
                    results.push_back(result);
                }
            }
        }

        std::wstring event = L"{\"param\":" + std::to_wstring(params) + L",\"results\":[";
        for (size_t i = 0; i < results.size(); ++i) {
            if (i) event += L",";
            event += L"{\"sid\":" + std::to_wstring(results[i].sid) +
                     L",\"res\":" + std::to_wstring(results[i].result) + L"}";
        }
        event += L"]}";
        sendJson(L"战斗结束", event);
        sendPrompt(L"战斗结束", results.empty() ? L"双方战斗结束" :
                   L"双方战斗结束，服务端返回" + std::to_wstring(results.size()) + L"条结算记录");

        return;
    }


    if (packet.opcode == Opcode::BATTLE_FSPK) {
        BoundedReader reader(data, size);
        BattleFspkData fspk;
        fspk.params = params;
        if (!reader.ReadI32(fspk.win)) return;
        fspk.hasReward = fspk.win >= 0;
        if (fspk.hasReward && (!reader.ReadI32(fspk.xianli) || !reader.ReadI32(fspk.zhangong))) return;
        sendJson(L"战斗结算", L"{\"params\":" + std::to_wstring(params) +
                 L",\"win\":" + std::to_wstring(fspk.win) +
                 L",\"xianli\":" + std::to_wstring(fspk.xianli) +
                 L",\"zhangong\":" + std::to_wstring(fspk.zhangong) + L"}");
        std::wstring fspkPrompt = L"战斗结算：胜负标记" + std::to_wstring(fspk.win);
        if (fspk.hasReward) {
            fspkPrompt += L"，仙力" + std::to_wstring(fspk.xianli) +
                          L"，战功" + std::to_wstring(fspk.zhangong);
        }
        sendPrompt(L"战斗结算", fspkPrompt);
        return;
    }

    if (packet.opcode == Opcode::COMBAT_SITE_OPTION) {
        BattleSiteData site;
        site.params = params;
        BoundedReader reader(data, size);
        if (params == BufDataType::COMBAT_SITE_ADD) {
            if (!reader.ReadI32(site.sn) || !reader.ReadI32(site.id) || !reader.ReadI32(site.round)) return;
        } else if (params == BufDataType::COMBAT_SITE_MD) {
            if (!reader.ReadI32(site.id) || !reader.ReadI32(site.round)) return;
        } else if (params == BufDataType::COMBAT_SITE_DEL) {
            if (!reader.ReadI32(site.id)) return;
        }
        sendJson(L"战斗场地", L"{\"params\":" + std::to_wstring(params) +
                 L",\"sn\":" + std::to_wstring(site.sn) +
                 L",\"id\":" + std::to_wstring(site.id) +
                 L",\"round\":" + std::to_wstring(site.round) + L"}");
        sendPrompt(L"战斗场地", L"战斗场地状态已更新");
        return;
    }

    if (packet.opcode == Opcode::COMBAT_SITE_EFFECT) {
        if (params != 1) return;
        BoundedReader reader(data, size);
        BattleSiteData site;
        site.params = params;
        BufData buf;
        buf.addOrRemove = BufDataType::BUF_TYPE_2;
        buf.bufId = BufDataType::SITE_RECOVER_ID;
        buf.param2 = 0;
        if (!reader.ReadI32(site.siteId) || !reader.ReadI32(buf.defId) || !reader.ReadI32(buf.param1)) return;
        buf.name = GetBufName(buf.bufId, buf.param1, buf.param2);
        buf.tipString = GetBufTipString(buf.bufId, buf.param1, buf.param2);
        BattleData next = GetCurrentBattleSnapshot();
        const std::wstring targetName = entityLabelBySid(next, buf.defId != 0 ? buf.defId : buf.atkId);
        ApplyBattleBuffBloodEffect(next, buf);
        BattleActivity::SyncAutoBattle(next, false);
        // Site effects are transient BATTLE_BUF events in AS3; do not persist
        // the recovery marker as a normal Buff row.
        ReplaceCurrentBattle(std::move(next));

        UpdateUIBattleData();
        sendJson(L"战斗场地", L"{\"params\":1,\"siteId\":" + std::to_wstring(site.siteId) +
                 L",\"defId\":" + std::to_wstring(buf.defId) +
                 L",\"param1\":" + std::to_wstring(buf.param1) + L"}");
        sendPrompt(L"战斗场地", targetName + L"受到场地效果：" + buf.name);
        return;
    }

    if (packet.opcode == Opcode::COMBAT_NET_PROBE_REQ) {
        BoundedReader reader(data, size);
        int32_t remote = 0, world = 0, gateway = 0;
        if (!reader.ReadI32(remote) || !reader.ReadI32(world) || !reader.ReadI32(gateway)) return;
        sendJson(L"战斗网络", L"{\"remote\":" + std::to_wstring(remote) +
                 L",\"world\":" + std::to_wstring(world) +
                 L",\"gateway\":" + std::to_wstring(gateway) + L"}");
        return;
    }

    if (packet.opcode == Opcode::COMBAT_NET_REPORT) {
        BoundedReader reader(data, size);
        int32_t report = 0;
        if (!reader.ReadI32(report)) return;
        sendJson(L"战斗网络", L"{\"report\":" + std::to_wstring(report) + L"}");
        return;
    }

    if (packet.opcode == Opcode::BATTLE_WITH || packet.opcode == Opcode::BATTLE_REQ_ON_SKILL) {
        sendJson(L"战斗关联", L"{\"opcode\":" + std::to_wstring(packet.opcode) +
                 L",\"params\":" + std::to_wstring(params) +
                 L",\"bodyBytes\":" + std::to_wstring(size) + L"}");
        return;
    }

    if (packet.opcode == Opcode::SPIRIT_LEVEL_UP) {
        BoundedReader reader(data, size);
        std::vector<int32_t> values;
        values.reserve(17);
        for (int i = 0; i < 17; ++i) {
            int32_t value = 0;
            if (!reader.ReadI32(value)) return;
            values.push_back(value);
        }
        // AS3 onSpiritLevelUp（BattleModel.as:488-495）升级后的技能列表**只读
        // skillid**，逐个读到 0 为止，没有 time 字段；旧实现每个技能多读一个
        // time，从第二个技能起整体错位，后面的 key/count/mod/attr 全读歪。
        std::vector<int32_t> newSkills;
        int32_t skillId = 0;
        if (!reader.ReadI32(skillId)) return;
        while (skillId != 0) {
            if (newSkills.size() >= 128) return;
            newSkills.push_back(skillId);
            if (!reader.ReadI32(skillId)) return;
        }
        // key/count/(skillid,time)*count/mod/attr 只在技能列表非空时才存在。
        const size_t skillCount = newSkills.size();
        if (!newSkills.empty()) {
            int32_t key = 0, count = 0;
            if (!reader.ReadI32(key) || !reader.ReadI32(count) || count < 0 || count > 128) return;
            for (int32_t i = 0; i < count; ++i) {
                int32_t id = 0, time = 0;
                if (!reader.ReadI32(id) || !reader.ReadI32(time)) return;
            }
            int32_t mod = 0, attr = 0;
            if (!reader.ReadI32(mod) || !reader.ReadI32(attr)) return;
        }
        // 升级会改变等级/血量上限：同一只妖怪若在名册里，顺手把上限对齐，
        // 否则战斗面板上的“当前生命/上限”会一直停在旧值。
        {
            BattleData next = GetCurrentBattleSnapshot();
            const int32_t uniqueId = values[0];
            const int32_t maxHp = values[11];
            bool touched = false;
            auto applyLevel = [&](std::vector<BattleEntity>& team) {
                for (auto& pet : team) {
                    if (pet.uniqueId == 0 || pet.uniqueId != uniqueId) continue;
                    pet.level = values[10];
                    if (maxHp > 0) {
                        // 上限变大时当前血量也加上同样的差值，避免刚升级就掉血。
                        if (pet.maxHp > 0 && maxHp > pet.maxHp) pet.hp += maxHp - pet.maxHp;
                        pet.maxHp = maxHp;
                        if (pet.hp > pet.maxHp) pet.hp = pet.maxHp;
                    }
                    touched = true;
                }
            };
            if (next.active && uniqueId != 0) {
                applyLevel(next.myPets);
                applyLevel(next.otherPets);
            }
            if (touched) {
                ReplaceCurrentBattle(std::move(next));
                UpdateUIBattleData();
            }
        }
        sendJson(L"战斗升级", L"{\"uniqueId\":" + std::to_wstring(values[0]) +
                 L",\"spiritId\":" + std::to_wstring(values[1]) +
                 L",\"level\":" + std::to_wstring(values[10]) +
                 L",\"maxHp\":" + std::to_wstring(values[11]) +
                 L",\"skillCount\":" + std::to_wstring(skillCount) + L"}");
        return;
    }

    if (packet.opcode == Opcode::BATTLE_NEWEXP) {
        // NEWEXP 是服务端确认战斗收尾的最后一个必经包；有些退出路径（客户端直接
        // 关战斗界面、END 丢包）没有 BATTLE_END_SEND，这里兜底清一次，避免残留。
        if (BattleSession::Instance().IsActive()) {
            ClearBattleState(true);
        }
        BoundedReader reader(data, size);
        uint32_t win = 0;
        if (!reader.ReadU32(win)) return;
        BattleActivity::MarkSettlement(win);
        int goodsCount = 0;
        int learnCount = 0;
        int expCount = 0;

        int32_t goodId = 0;
        if (!reader.ReadI32(goodId)) return;
        while (goodId != 0) {
            if (++goodsCount > 1024) return;
            int32_t amount = 0;
            if (!reader.ReadI32(amount) || !reader.ReadI32(goodId)) return;
        }

        int32_t spiritId = 0;
        if (!reader.ReadI32(spiritId)) return;
        while (spiritId != 0) {
            if (++learnCount > 1024) return;
            for (int i = 0; i < 7; ++i) {
                int32_t value = 0;
                if (!reader.ReadI32(value)) return;
            }
            if (!reader.ReadI32(spiritId)) return;
        }

        int32_t expType = 0;
        if (!reader.ReadI32(expType)) return;
        while (expType != 0) {
            if (++expCount > 1024) return;
            if (expType == 1) {
                for (int i = 0; i < 8; ++i) {
                    int32_t value = 0;
                    if (!reader.ReadI32(value)) return;
                }
            } else if (expType == 2) {
                for (int i = 0; i < 18; ++i) {
                    int32_t value = 0;
                    if (!reader.ReadI32(value)) return;
                }
                // AS3 receiveNewBattleExp（BattleModel.as:666-673）：升级技能列表
                // 同样只读 skillid、读到 0 为止，不含 time。旧实现每个技能多读一个
                // time，一旦这只妖怪升级带多个新技能，后续 key/count/mod/attr 就
                // 全部错位，把后面的 saveExp 与下一条 expType 一起读歪。
                int32_t skillFlag = 0;
                if (!reader.ReadI32(skillFlag)) return;
                int skillCount = 0;
                while (skillFlag != 0) {
                    if (++skillCount > 128) return;
                    if (!reader.ReadI32(skillFlag)) return;
                }
                if (skillCount > 0) {
                    int32_t key = 0, count = 0;
                    if (!reader.ReadI32(key) || !reader.ReadI32(count) || count < 0 || count > 128) return;
                    for (int32_t i = 0; i < count; ++i) {
                        int32_t id = 0, time = 0;
                        if (!reader.ReadI32(id) || !reader.ReadI32(time)) return;
                    }
                    int32_t mod = 0, attr = 0;
                    if (!reader.ReadI32(mod) || !reader.ReadI32(attr)) return;
                }
            } else {
                return;
            }
            if (!reader.ReadI32(expType)) return;
        }
        int32_t saveExp = 0;
        if (!reader.ReadI32(saveExp)) return;
        sendJson(L"战斗经验", L"{\"type\":" + std::to_wstring(params) +
                 L",\"win\":" + std::to_wstring(win) +
                 L",\"goods\":" + std::to_wstring(goodsCount) +
                 L",\"learnPowers\":" + std::to_wstring(learnCount) +
                 L",\"spiritExp\":" + std::to_wstring(expCount) +
                 L",\"saveExp\":" + std::to_wstring(saveExp) + L"}");
    }
}

void PacketParser::ProcessBattlePacket(const GamePacket& packet) {
    ProcessBattlePacketSafe(packet);
}

void PacketParser::ProcessMonsterPacket(const GamePacket& packet) {
    if (packet.opcode != Opcode::MONSTER_LIST) return;

    size_t offset = 0;
    ByteReader reader(packet.body, offset);
    size_t size = packet.body.size();

    if (offset + 8 > size) return;
    
    int32_t sn = reader.I32();
    int32_t mcount = reader.I32();

    std::vector<MonsterItem> monsters;

    for (int j = 0; j < mcount && offset + 4 <= size; j++) {
        MonsterItem monster;
        
        monster.id = reader.I32();
        if (monster.id == 0) break;
        
        if (offset + 8 > size) break;
        monster.type_id = reader.I32();
        monster.iid = reader.I32();
        
        // 从名称表获取妖怪名称
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            auto it = g_petNames.find(monster.iid);
            monster.name = (it != g_petNames.end()) ? it->second : L"未知妖怪";
        }
        
        // 从映射表获取系别（AS3中系别来自monsterIntro.elem，即sprite.xml）
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            auto elemIt = g_petElems.find(monster.iid);
            if (elemIt != g_petElems.end()) {
                monster.type = elemIt->second;
                auto nameIt = g_elemNames.find(monster.type);
                monster.typeName = (nameIt != g_elemNames.end()) ? nameIt->second : L"未知";
            } else {
                monster.type = 0;
                monster.typeName = L"未知";
            }
        }
        
        if (offset + 72 > size) break;
        monster.isfirst = reader.I32();
        monster.level = reader.I32();
        monster.exp = reader.I32();
        reader.I32();  // type字段（封包中的type，忽略，使用sprite.xml中的elem）
        monster.forbitItem = reader.I32();
        monster.attack = reader.I32();
        monster.defence = reader.I32();
        monster.magic = reader.I32();
        monster.resistance = reader.I32();
        monster.strength = reader.I32();
        monster.hp = reader.I32();
        monster.speed = reader.I32();
        monster.mold = reader.I32();
        monster.state = reader.I32();
        monster.needExp = reader.I32();
        monster.timetxt = reader.I32();
        monster.sex = reader.I32();
        
        // 学习力
        if (offset + 24 > size) break;
        reader.I32(); // attackLearnValue
        reader.I32(); // defenceLearnValue
        reader.I32(); // magicLearnValue
        reader.I32(); // resistanceLearnValue
        reader.I32(); // hpLearnValue
        reader.I32(); // speedLearnVale
        
        // 资质原始值（0-31范围）
        if (offset + 24 > size) break;
        int32_t attackGeniusValue = reader.I32();
        int32_t defenceGeniusValue = reader.I32();
        int32_t magicGeniusValue = reader.I32();
        int32_t resistanceGeniusValue = reader.I32();
        int32_t hpGeniusValue = reader.I32();
        int32_t speedGeniusValue = reader.I32();
        
        // 资质等级计算函数（根据SpiritGenius.cheakGenius）
        auto checkGenius = [](int32_t value) -> int {
            if (value >= 0 && value <= 5) return 2;
            if (value >= 6 && value <= 11) return 3;
            if (value >= 12 && value <= 17) return 4;
            if (value >= 18 && value <= 26) return 5;
            if (value >= 27 && value <= 31) return 6;
            return 1;  // 默认/异常值
        };
        
        // 计算各项资质等级
        int attackGenius = checkGenius(attackGeniusValue);
        int defenceGenius = checkGenius(defenceGeniusValue);
        int magicGenius = checkGenius(magicGeniusValue);
        int resistanceGenius = checkGenius(resistanceGeniusValue);
        int hpGenius = checkGenius(hpGeniusValue);
        int speedGenius = checkGenius(speedGeniusValue);
        
        // 总资质计算（根据SpiritGenius.countGeniusType）
        int totalScore = attackGenius + defenceGenius + magicGenius + resistanceGenius + hpGenius + speedGenius - 6;
        monster.geniusType = 0;
        if (totalScore >= 5 && totalScore <= 9) monster.geniusType = 1;
        else if (totalScore >= 10 && totalScore <= 14) monster.geniusType = 2;
        else if (totalScore >= 15 && totalScore <= 19) monster.geniusType = 3;
        else if (totalScore >= 20 && totalScore <= 24) monster.geniusType = 4;
        else if (totalScore >= 25 && totalScore <= 29) monster.geniusType = 5;
        else if (totalScore == 30) monster.geniusType = 6;
        
        // 获取资质名称
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            auto it = g_aptitudeNames.find(monster.geniusType);
            if (it != g_aptitudeNames.end()) {
                monster.aptitudeName = it->second;
            } else {
                monster.aptitudeName = L"未知资质";
            }
        }
        
        // 从mold获取性格名称（mold是性格索引，从g_geniusNames映射）
        {
            std::lock_guard<std::mutex> lock(g_dataMapsMutex);
            auto it = g_geniusNames.find(monster.mold);
            if (it != g_geniusNames.end()) {
                monster.geniusName = it->second;
            } else {
                monster.geniusName = L"未知";
            }
        }
        
        // 添加资质列表用于UI显示（包含原始值和等级）
        auto addGenius = [&](int32_t val, int32_t level, const std::wstring& name) {
            MonsterGenius g;
            g.name = name;
            g.value = val;
            g.level = level;
            monster.geniusList.push_back(g);
        };
        addGenius(attackGeniusValue, attackGenius, L"攻击");
        addGenius(defenceGeniusValue, defenceGenius, L"防御");
        addGenius(magicGeniusValue, magicGenius, L"法术");
        addGenius(resistanceGeniusValue, resistanceGenius, L"抗性");
        addGenius(hpGeniusValue, hpGenius, L"体力");
        addGenius(speedGeniusValue, speedGenius, L"速度");
        
        // aptitude 与 geniusType 保持一致（总资质等级）
        monster.aptitude = monster.geniusType;
        
        // 绝学
        if (offset + 12 > size) break;
        reader.I32(); // peerlessId
        reader.I32(); // peerlessStatus
        reader.I32(); // tempPeerlessNum
        
        // 技能数量
        if (offset + 4 > size) break;
        int32_t skillcount = reader.I32();
        
        // 读取技能列表
        for (int i = 0; i < skillcount && offset + 12 <= size; i++) {
            MonsterSkill skill;
            skill.id = reader.I32();
            int32_t skillPp = reader.I32();
            skill.maxPp = reader.I32();
            skill.pp = skillPp;
            {
                std::lock_guard<std::mutex> lock(g_dataMapsMutex);
                auto it = g_skillNames.find(skill.id);
                skill.name = (it != g_skillNames.end()) ? it->second : L"";
            }
            monster.skills.push_back(skill);
        }
        
        // 读取额外技能列表（以0结尾）
        int32_t tempskillid = 1;
        while (tempskillid != 0 && offset + 4 <= size) {
            tempskillid = reader.I32();
            // 跳过，不处理额外技能
        }
        
        // 不可用技能数量
        if (offset + 4 > size) break;
        (void)reader.I32();
        // 跳过不可用技能
        
        // 灵玉数量
        if (offset + 4 > size) break;
        int32_t symmLength = reader.I32();
        
        // 读取灵玉列表
        for (int z = 0; z < symmLength && offset + 12 <= size; z++) {
            MonsterSymm symm;
            symm.place = reader.I32();
            symm.id = reader.I32();
            symm.index = reader.I32();
            symm.name = L"";  // 灵玉名称需要另外查询
            monster.symmList.push_back(symm);
        }
        
        // 读取额外技能列表（以-1或0结尾）
        if (offset + 4 <= size) {
            tempskillid = reader.I32();
            while (tempskillid != -1 && tempskillid != 0 && offset + 4 <= size) {
                tempskillid = reader.I32();
            }
        }
        
        // 读取另一组额外技能列表（以-1或0结尾）
        if (offset + 4 <= size) {
            tempskillid = reader.I32();
            while (tempskillid != -1 && tempskillid != 0 && offset + 4 <= size) {
                tempskillid = reader.I32();
            }
        }
        
        monsters.push_back(monster);
    }

    // 保存妖怪数据到全局变量（用于副本跳层等功能）
    {
        // 三步一起换，读端拿到的要么是旧表要么是新表，不会是半张。
        std::lock_guard<std::mutex> lock(g_monsterDataMutex);
        g_monsterData.sn = sn;
        g_monsterData.count = mcount;
        g_monsterData.monsters = monsters;
    }

    // 通知副本跳层模块妖怪数据已收到（写线程=收包线程，读线程=跳层线程）
    BattleActivity::NotifyMonsterDataReceived();

    // 构建JSON并发送到UI
    std::wstring jsData = L"{\"sn\":" + std::to_wstring(sn) + L",\"count\":" + std::to_wstring(mcount) + L",\"monsters\":[";
    
    for (size_t i = 0; i < monsters.size(); i++) {
        const auto& m = monsters[i];
        jsData += L"{\"id\":" + std::to_wstring(m.id) +
                  L",\"iid\":" + std::to_wstring(m.iid) +
                  L",\"name\":\"" + m.name + L"\"" +
                  L",\"isfirst\":" + std::to_wstring(m.isfirst) +
                  L",\"level\":" + std::to_wstring(m.level) +
                  L",\"exp\":" + std::to_wstring(m.exp) +
                  L",\"needExp\":" + std::to_wstring(m.needExp) +
                  L",\"type\":" + std::to_wstring(m.type) +
                  L",\"typeName\":\"" + m.typeName + L"\"" +
                  L",\"attack\":" + std::to_wstring(m.attack) +
                  L",\"defence\":" + std::to_wstring(m.defence) +
                  L",\"magic\":" + std::to_wstring(m.magic) +
                  L",\"resistance\":" + std::to_wstring(m.resistance) +
                  L",\"hp\":" + std::to_wstring(m.hp) +
                  L",\"speed\":" + std::to_wstring(m.speed) +
                  L",\"mold\":" + std::to_wstring(m.mold) +
                  L",\"sex\":" + std::to_wstring(m.sex) +
                  L",\"geniusType\":" + std::to_wstring(m.geniusType) +
                  L",\"geniusName\":\"" + m.geniusName + L"\"" +
                  L",\"aptitude\":" + std::to_wstring(m.aptitude) +
                  L",\"aptitudeName\":\"" + m.aptitudeName + L"\"" +
                  L",\"geniusList\":[";
        
        for (size_t g = 0; g < m.geniusList.size(); g++) {
            jsData += L"{\"name\":\"" + m.geniusList[g].name + L"\",\"value\":" + std::to_wstring(m.geniusList[g].value) + L",\"level\":" + std::to_wstring(m.geniusList[g].level) + L"}";
            if (g < m.geniusList.size() - 1) jsData += L",";
        }
        
        jsData += L"],\"skills\":[";
        for (size_t s = 0; s < m.skills.size(); s++) {
            jsData += L"{\"id\":" + std::to_wstring(m.skills[s].id) +
                      L",\"name\":\"" + m.skills[s].name + L"\"" +
                      L",\"pp\":" + std::to_wstring(m.skills[s].pp) +
                      L",\"maxPp\":" + std::to_wstring(m.skills[s].maxPp) + L"}";
            if (s < m.skills.size() - 1) jsData += L",";
        }
        
        jsData += L"],\"symmList\":[";
        for (size_t z = 0; z < m.symmList.size(); z++) {
            jsData += L"{\"place\":" + std::to_wstring(m.symmList[z].place) +
                      L",\"id\":" + std::to_wstring(m.symmList[z].id) +
                      L",\"index\":" + std::to_wstring(m.symmList[z].index) + L"}";
            if (z < m.symmList.size() - 1) jsData += L",";
        }
        
        jsData += L"]}";
        if (i < monsters.size() - 1) jsData += L",";
    }
    
    jsData += L"]}";
    
    std::wstring jsCode = L"if(window.updateMonsterUI) { window.updateMonsterUI(" + jsData + L"); }";
    UIBridge::Instance().ExecuteJS(jsCode);
}

// ============================================================================
// zlib 函数导出实现
// ============================================================================

ZlibUncompressFunc GetZlibUncompress() {
    return &uncompress;
}
